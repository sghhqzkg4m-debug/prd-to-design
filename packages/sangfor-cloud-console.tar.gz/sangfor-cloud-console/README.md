# Sangfor Cloud Console Skill

This repository is the `sangfor-cloud-console` Codex skill for generating or modifying Sangfor Cloud BG console HTML pages.

## Install

Clone or copy this repository into your Codex skills directory:

```bash
mkdir -p ~/.codex/skills
cp -R . ~/.codex/skills/sangfor-cloud-console
```

Then invoke it with:

```text
Use $sangfor-cloud-console to create a Sangfor Cloud BG console HTML page from my requirements.
```

## Contents

- `SKILL.md`: skill entrypoint and workflow.
- `references/`: component and design references loaded on demand.
- `assets/`: reusable iconfont resources.
- `templates/`: reusable HTML templates and images.
