# 列表页模板

列表页用于消息、告警、事件流、任务流、通知和搜索结果等场景。

## 模板文件

列表页分为四类页面模板，一个页面一个单文件 HTML：

- 基础列表页：`templates/list-page/basic-list-page.html`
- 概览列表页：`templates/list-page/overview-list-page.html`
- 折叠列表页：`templates/list-page/collapse-list-page.html`
- 卡片列表页：`templates/list-page/card-list-page.html`

当前基础列表页已经完成，其他三类先提供占位模板，后续按对应样式继续扩充。

生成列表页时先参考：

- `references/components/列表-List.md`
- `references/components/按钮-Button.md`
- `references/components/空状态-Empty.md`
- `references/components/加载状态-Loading.md`
- `references/components/分页器-Pagination.md`

## 生成规则

- 保留全局导航和侧边导航。
- 页面框架复用 `templates/table-page/带侧边导航.html` 的顶部导航、左侧导航、内容区滚动结构。
- 所有带顶部全局导航的列表页，都必须把左上角菜单按钮关联到 `templates/service-catalog-nav/service-catalog-nav.html`。
- 内容区使用列表组件，不使用表格组件替代列表。
- 列表项应高密度、可扫描。
- 列表项可以包含标题、摘要、状态、时间、操作。
- 列表中的操作按钮必须符合 `references/components/按钮-Button.md`，且列表场景下按钮不固定 80px 最小宽度。
- 图标必须使用 `assets/iconfont/icon-symbols.html` 中的 `vtv-icon-*`。
- 大量数据使用分页或加载更多。
- 不把列表页做成营销卡片流。
