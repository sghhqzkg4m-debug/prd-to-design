---
name: "云BG设计规范-基础组件-列表（List）"
description: "提供列表组件的设计规范、交互规则与最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现列表组件时调用。"
step:
  1. 需求解析：确认列表尺寸（small/regular/large）、内容类型（base/icon-text/text-desc/text）、是否需要操作区、禁用态。
  2. 视觉设计：严格使用本文档中的尺寸、颜色、间距、圆角、边框和状态，不自行推导列表项高度。
  3. 代码生成：按本文档 HTML/CSS 结构生成列表，保证同一列表内尺寸一致。
---

# 列表 List

## 来源与适用范围

列表用于展示同类结构数据，如消息、任务、文档、文件、搜索结果、可选资源、配置项等。

本规范对应 Seer / MasterGo 云BG组件库中的：

- `基础列表单（组合）`
- `基础列表单（单原子）`
- `icon 16*16px 高度默认52px`
- `icon 40*40px 高度默认64px`
- `icon 40*40px 高度默认88px`

完整静态示例见仓库根目录：`examples/list-examples.html`。

读取本文件生成列表时，必须优先匹配下方尺寸表，不要继续使用旧的 40px / 48px / 56px 泛化高度。

## 组件能力

### 尺寸枚举

| 尺寸名 | class | 列表项高度 | 图标容器 | 图标实际尺寸 | 适用场景 |
| --- | --- | ---: | ---: | ---: | --- |
| 小尺寸 | `.list--small` | 52px | 16px × 16px | 16px × 16px | 高密度信息、设置项、轻量消息、可选项 |
| 常规尺寸 | `.list--regular` | 64px | 40px × 40px | 16px × 16px | 默认列表、图标+标题+描述 |
| 大尺寸 | `.list--large` | 88px | 40px × 40px | 16px × 16px | 内容强调、说明较长、卡片式列表 |

### 内容枚举

| 内容类型 | class | 结构 | 说明 |
| --- | --- | --- | --- |
| 基础显示 | `.list--base` | 左侧状态图标 / 主标题 / 右侧操作 | 适合配置项、任务项、可操作条目 |
| 图标+文字 | `.list--icon-text` | 左侧图标 / 主标题 / 右侧操作 | 适合入口列表、资源列表 |
| 文字+描述 | `.list--text-desc` | 主标题 / 描述 / 右侧操作 | 适合消息、说明、搜索结果 |
| 文字 | `.list--text` | 主标题 / 右侧操作 | 适合简单菜单、轻量列表 |

同一个列表容器内不要混用不同高度。如果业务确实需要混排，拆成多个列表区域。

## 尺寸规范

### 列表容器

| 属性 | 值 |
| --- | --- |
| 背景 | `#FFFFFF` / `var(--color-gray-l60)` |
| 圆角 | 6px |
| 边框 | 1px solid `#CCD2D9` / `var(--color-blue-gray-default)` |
| 文字默认色 | `#3E4A59` / `var(--color-graphite-black-l30)` |
| 宽度 | 跟随父容器，默认 `width: 100%` |
| 溢出 | `overflow: hidden`；长列表由父容器或列表自身滚动 |

### 列表项布局

| 尺寸 | 高度 | 左右内边距 | 左侧图标容器 | 图标实际尺寸 | 图标与内容间距 | 标题字号 | 描述字号 | 右侧操作按钮 |
| --- | ---: | --- | ---: | ---: | ---: | --- | --- | ---: |
| 小尺寸 | 52px | 左 16px / 右 0px | 16px | 16px | 8px | 14px / 20px / 600 | 12px / 17px / 400 | `btn-sm` |
| 常规尺寸 | 64px | 左 16px / 右 0px | 40px | 16px | 12px | 14px / 20px / 600 | 12px / 17px / 400 | `btn-normal` |
| 大尺寸 | 88px | 左 16px / 右 0px | 40px | 16px | 12px | 16px / 22px / 500 | 12px / 17px / 400 | `btn-lg` |

说明：

- 小尺寸使用 16px 图标，不加圆形外框，列表项高度固定 52px。
- 常规尺寸和大尺寸使用 40px 圆形图标容器，内部图标来自图标库，实际尺寸 16px。
- 有描述时，标题和描述垂直排列，内容区整体垂直居中。
- 没有描述时，标题单行垂直居中。
- 右侧操作区贴齐列表项右侧，右侧间距为 0px；操作区和主内容之间至少 16px。
- 列表操作按钮必须引用 `./按钮-Button.md`，不允许在列表组件中自定义一套按钮高度、圆角、padding 或状态。
- 小尺寸列表使用按钮 `small / .btn-sm`：高度 24px、字号 12px、圆角 2px、左右 padding 8px。
- 常规尺寸列表使用按钮 `normal / .btn-normal`：高度 32px、字号 12px、圆角 4px、左右 padding 12px。
- 大尺寸列表使用按钮 `large / .btn-lg`：高度 32px、字号 14px、圆角 4px、左右 padding 16px。
- 操作按钮类型使用次要按钮 `secondary / .btn-secondary`；更多按钮使用 `secondary + icon-only`，图标 16px。
- 列表操作按钮不使用按钮组件的 `min-width: 80px` 约束；在列表场景中 `.cloud-list-action { min-width: 0; }`，宽度由文字内容和按钮 padding 决定。

### 行内分割线

| 属性 | 值 |
| --- | --- |
| 位置 | 每个列表项底部 |
| 颜色 | `#DCE0E6` / `var(--color-blue-gray-l10)` |
| 高度 | 1px |
| 首末处理 | 最后一项默认不显示底部分割线 |

## 颜色规范

| 元素 | 颜色 | Token / 说明 |
| --- | --- | --- |
| 容器背景 | `#FFFFFF` | `gray.l60` |
| 容器描边 | `#CCD2D9` | `blue-gray.default` |
| 分割线 | `#DCE0E6` | `blue-gray.l10` |
| 标题文字 | `#242A33` / `#3E4A59` | 优先 `graphite-black.default/l30` |
| 描述文字 | `#999999` | `gray.d30` |
| 弱化文字 | `#B5BAC2` | `blue-gray.d20` |
| Hover 背景 | `#F5F6F8` | `blue-gray.l80` |
| Disabled 透明度 | `opacity: .4` | 禁用态不响应 hover |

## 状态规范

| 状态 | 样式 |
| --- | --- |
| Default | 白底，底部分割线，文字正常显示 |
| Hover | 背景 `#F5F6F8`，鼠标为 pointer |
| Disabled | 整行透明度 40%，鼠标为 not-allowed，不触发 hover |
| Focus | 可交互列表项需要 1px `#1770E6` 外描边或同等 focus ring |

## DOM 结构

生成时必须使用稳定结构，方便样式复用：

```html
<div class="cloud-list list--regular list--icon-text">
  <button class="cloud-list-item" type="button">
    <span class="cloud-list-leading">
      <svg class="icon cloud-list-icon" aria-hidden="true">
        <use href="#vtv-icon-resource-adiministration"></use>
      </svg>
    </span>
    <span class="cloud-list-body">
      <span class="cloud-list-title">Title 14 px，字重 600，#000</span>
      <span class="cloud-list-desc">描述信息 12px，字重 400，#999999</span>
    </span>
    <span class="cloud-list-actions">
      <span class="btn btn-secondary btn-normal cloud-list-action">操作1</span>
      <span class="btn btn-secondary btn-normal cloud-list-action">操作2</span>
      <span class="btn btn-secondary btn-normal btn-icon-only cloud-list-more">
        <svg class="icon" aria-hidden="true"><use href="#vtv-icon-comp-more"></use></svg>
      </span>
    </span>
  </button>
</div>
```

结构要求：

- 容器固定使用 `.cloud-list`。
- 列表项固定使用 `.cloud-list-item`。
- 左侧图标区域固定使用 `.cloud-list-leading` 和 `.cloud-list-icon`。
- 图标必须使用 `../../assets/iconfont/icon-symbols.html` 中的 `vtv-icon-*`，单文件 HTML 需要内联所用 symbol；禁止用 CSS 伪元素或临时 SVG path 自造图标。
- 文案区域固定使用 `.cloud-list-body`、`.cloud-list-title`、`.cloud-list-desc`。
- 操作区域固定使用 `.cloud-list-actions`。
- 列表项可用 `button`、`a` 或 `div role="button"`；有点击行为时优先 `button` 或 `a`。

## 标准 CSS

```css
.cloud-list {
  width: 100%;
  overflow: hidden;
  color: #3E4A59;
  background: #FFFFFF;
  border: 1px solid #CCD2D9;
  border-radius: 6px;
}

.cloud-list-item {
  position: relative;
  width: 100%;
  height: var(--list-item-height);
  padding: 0 0 0 16px;
  border: 0;
  border-bottom: 1px solid #DCE0E6;
  display: flex;
  align-items: center;
  gap: var(--list-gap);
  color: inherit;
  background: #FFFFFF;
  text-align: left;
  cursor: pointer;
}

.cloud-list-item:last-child {
  border-bottom: 0;
}

.cloud-list-item:hover {
  background: #F5F6F8;
}

.cloud-list-item.is-disabled {
  opacity: .4;
  cursor: not-allowed;
}

.cloud-list-item.is-disabled:hover {
  background: #FFFFFF;
}

.cloud-list-leading {
  width: var(--list-leading-size);
  height: var(--list-leading-size);
  flex: 0 0 var(--list-leading-size);
  border: var(--list-leading-border);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #1770E6;
  background: #FFFFFF;
}

.cloud-list-icon {
  width: var(--list-icon-size);
  height: var(--list-icon-size);
  fill: currentColor;
}

.icon {
  width: 16px;
  height: 16px;
  fill: currentColor;
  overflow: hidden;
  flex-shrink: 0;
}

.cloud-list-body {
  min-width: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.cloud-list-title {
  min-width: 0;
  color: #000000;
  font-size: var(--list-title-size);
  line-height: var(--list-title-line);
  font-weight: var(--list-title-weight);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cloud-list-desc {
  margin-top: 2px;
  color: #999999;
  font-size: 12px;
  line-height: var(--list-desc-line);
  font-weight: 400;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cloud-list-actions {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-left: 16px;
  margin-right: 0;
}

/* 以下按钮样式摘自 按钮-Button.md；列表只做尺寸映射，不自定义按钮规范。 */
.btn {
  position: relative;
  border: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-family: inherit;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  outline: none;
}

.btn-secondary {
  color: #404655;
  background: #FFFFFF;
  border: 1px solid #D9DDE5;
}

.btn-secondary:hover {
  border-color: #9CA3AF;
}

.btn-secondary:active {
  border-color: #7BB0FA;
}

.btn-secondary:disabled,
.cloud-list-item.is-disabled .btn-secondary {
  color: rgba(64, 70, 85, .4);
  background: rgba(255, 255, 255, .4);
  border-color: rgba(217, 221, 229, .4);
  cursor: not-allowed;
}

.btn-sm {
  min-width: 0;
  height: 24px;
  padding: 0 8px;
  border-radius: 2px;
  font-size: 12px;
  line-height: 17px;
}

.btn-normal {
  min-width: 0;
  height: 32px;
  padding: 0 12px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 17px;
}

.btn-lg {
  min-width: 0;
  height: 32px;
  padding: 0 16px;
  border-radius: 4px;
  font-size: 14px;
  line-height: 20px;
}

.btn-icon-only {
  min-width: 32px;
  width: 32px;
  height: 32px;
  padding: 0;
}

.btn-icon-only.btn-sm {
  min-width: 24px;
  width: 24px;
  height: 24px;
}

.btn-icon-only.btn-lg {
  min-width: 36px;
  width: 36px;
  height: 36px;
}

.cloud-list-action {
  min-width: 0;
}

.list--small {
  --list-item-height: 52px;
  --list-leading-size: 16px;
  --list-icon-size: 16px;
  --list-leading-border: 0;
  --list-gap: 8px;
  --list-title-size: 14px;
  --list-title-line: 20px;
  --list-title-weight: 600;
  --list-desc-line: 17px;
}

.list--regular {
  --list-item-height: 64px;
  --list-leading-size: 40px;
  --list-icon-size: 16px;
  --list-leading-border: 1px solid #DCE1E8;
  --list-gap: 12px;
  --list-title-size: 14px;
  --list-title-line: 20px;
  --list-title-weight: 600;
  --list-desc-line: 17px;
}

.list--large {
  --list-item-height: 88px;
  --list-leading-size: 40px;
  --list-icon-size: 16px;
  --list-leading-border: 1px solid #DCE1E8;
  --list-gap: 12px;
  --list-title-size: 16px;
  --list-title-line: 22px;
  --list-title-weight: 500;
  --list-desc-line: 18px;
}

.list--text .cloud-list-leading,
.list--text-desc .cloud-list-leading {
  display: none;
}

.list--text .cloud-list-desc {
  display: none;
}
```

## 尺寸示例

### 小尺寸：52px，16px 图标

```html
<div class="cloud-list list--small list--base">
  <button class="cloud-list-item" type="button">
    <span class="cloud-list-leading">
      <svg class="icon cloud-list-icon" aria-hidden="true">
        <use href="#vtv-icon-resource-adiministration"></use>
      </svg>
    </span>
    <span class="cloud-list-body">
      <span class="cloud-list-title">Title 14px，字重 500</span>
      <span class="cloud-list-desc">这是一段描述文字</span>
    </span>
    <span class="cloud-list-actions">
      <span class="btn btn-secondary btn-sm cloud-list-action">操作1</span>
      <span class="btn btn-secondary btn-sm cloud-list-action">操作2</span>
      <span class="btn btn-secondary btn-sm btn-icon-only cloud-list-more">
        <svg class="icon" aria-hidden="true"><use href="#vtv-icon-comp-more"></use></svg>
      </span>
    </span>
  </button>
</div>
```

### 常规尺寸：64px，40px 图标

```html
<div class="cloud-list list--regular list--icon-text">
  <button class="cloud-list-item" type="button">
    <span class="cloud-list-leading">
      <svg class="icon cloud-list-icon" aria-hidden="true">
        <use href="#vtv-icon-resource-adiministration"></use>
      </svg>
    </span>
    <span class="cloud-list-body">
      <span class="cloud-list-title">Title 14px，字重 500</span>
      <span class="cloud-list-desc">描述信息最多一行，超出显示省略号</span>
    </span>
    <span class="cloud-list-actions">
      <span class="btn btn-secondary btn-normal cloud-list-action">操作1</span>
      <span class="btn btn-secondary btn-normal btn-icon-only cloud-list-more">
        <svg class="icon" aria-hidden="true"><use href="#vtv-icon-comp-more"></use></svg>
      </span>
    </span>
  </button>
</div>
```

### 大尺寸：88px，40px 图标

```html
<div class="cloud-list list--large list--text-desc">
  <button class="cloud-list-item" type="button">
    <span class="cloud-list-body">
      <span class="cloud-list-title">Title 16px，字重 500</span>
      <span class="cloud-list-desc">大尺寸列表允许承载更强说明，但仍保持单行省略。</span>
    </span>
    <span class="cloud-list-actions">
      <span class="btn btn-secondary btn-lg cloud-list-action">操作1</span>
      <span class="btn btn-secondary btn-lg cloud-list-action">操作2</span>
    </span>
  </button>
</div>
```

## 生成决策

| 用户描述 | 应选尺寸 | 内容类型 |
| --- | --- | --- |
| 消息列表、通知列表、设置项 | 小尺寸 `52px` | 基础显示或文字+描述 |
| 文件列表、任务列表、资源入口 | 常规尺寸 `64px` | 图标+文字或文字+描述 |
| 带较强视觉入口、卡片式条目 | 大尺寸 `88px` | 图标+文字或文字+描述 |
| 只展示名称和操作 | 小尺寸或常规尺寸 | 文字 |
| 左侧需要圆形状态/单选标识 | 小尺寸优先 | 基础显示 |

## 交互规则

- 点击列表项：进入详情或展开详情，具体按业务需求。
- Hover：整行变为 `#F5F6F8`。
- 操作按钮：最多展示 2 个文字操作 + 1 个更多按钮；更多操作应接下拉菜单组件。
- 更多操作下拉菜单必须引用 `./下拉菜单-Dropdown.md`：菜单宽度 160px，内边距 `4px 1px`，边框 `poseidon-blue.default`，菜单项高度 32px，hover 背景 `gray.l40`，文字 `gray.d50`。
- 列表页工具栏里的筛选选择器若展开为普通文字选项菜单，也需区分 hover 与 selected：hover 背景 `gray.l40`，文字 `gray.d50`；当前选中项背景 `poseidon-blue.l60`，文字 `gray.d50`。
- 长文本：标题和描述都必须单行省略，不允许撑高列表项。
- 列表滚动：列表外层或父容器滚动，不允许列表项高度随内容变化。

## 禁止事项

- 禁止使用 40px / 48px / 56px 旧高度。
- 禁止同一个 `.cloud-list` 内混用 52px、64px、88px。
- 禁止因为描述文字过长把列表项撑高。
- 禁止右侧操作超过 3 个直接铺开。
- 禁止用卡片大圆角、投影或营销式卡片替代基础列表。
- 禁止临时自造图标尺寸；小尺寸固定 16px，常规/大尺寸固定 40px。

## 生成前检查

- [ ] 是否明确使用 `list--small`、`list--regular` 或 `list--large`。
- [ ] 是否明确使用 `list--base`、`list--icon-text`、`list--text-desc` 或 `list--text`。
- [ ] 列表项高度是否严格为 52px / 64px / 88px。
- [ ] 图标尺寸是否严格为 16px 或 40px。
- [ ] 容器是否白底、6px 圆角、蓝灰描边。
- [ ] 标题/描述是否单行省略。
- [ ] Hover、Disabled 状态是否完整。
- [ ] 分割线是否使用 `#DCE0E6 / blue-gray.l10`。
- [ ] 操作下拉菜单与筛选下拉选项 hover 是否使用 `gray.l40` 背景，筛选当前选中项是否使用 `poseidon-blue.l60` 背景。
