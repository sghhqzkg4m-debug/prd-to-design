---
name: "云BG设计规范-基础组件-加载状态（loading）"
description: "提供加载状态组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现加载状态组件时调用。"
step:
  1. 需求解析：理解用户需要的加载类型（加载指示器、加载文案、全屏加载）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 加载状态 Loading

## 概述

加载状态用于反馈数据加载或操作处理中的状态，告知用户等待。

- **来源**：深信服云BG设计部
- **类型**：状态反馈组件
- **适用场景**：页面加载、数据获取、操作处理

---

## 类型 Types

### 1. 加载指示器 (Spinner)

用于局部加载提示，如按钮加载、区域加载。

| 尺寸 | 尺寸值 | 适用场景 |
|------|--------|----------|
| 小 | 16px | 按钮内、行内 |
| 中 | 24px | 卡片内、区域 |
| 大 | 32px | 全屏加载 |

### 2. 加载文案 (Loading with Text)

用于需要说明加载内容的场景。

```html
<div class="loading-with-text">
  <span class="loading-spinner"></span>
  <span class="loading-text">加载中...</span>
</div>
```

### 3. 全屏加载 (Fullscreen Loading)

用于阻止用户操作的全局加载状态。

```html
<div class="loading-fullscreen">
  <div class="loading-card">
    <span class="loading-spinner-large"></span>
    <p class="loading-text">正在加载...</p>
  </div>
</div>
```

---

## 样式 Styles

### 加载指示器

```css
/* 中等尺寸（默认） */
.loading-spinner {
  width: 24px;
  height: 24px;
  border: 3px solid var(--color-gray-l20); /* #EEEEEE */
  border-top-color: var(--color-poseidon-blue-default); /* #1770E6 */
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* 小尺寸 */
.loading-spinner-sm {
  width: 16px;
  height: 16px;
  border-width: 2px;
}

/* 大尺寸 */
.loading-spinner-lg {
  width: 32px;
  height: 32px;
  border-width: 4px;
}
```

### 加载文案

```css
.loading-with-text {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.loading-text {
  font-size: 14px;
  color: var(--color-gray-d40); /* #666666 */
}
```

### 全屏加载

```css
.loading-fullscreen {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: var(--color-overlay-mask); /* rgba(0,0,0,0.4) */
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.loading-card {
  background: var(--color-gray-l60); /* #FFFFFF */
  padding: 24px 32px;
  border-radius: var(--radius-default); /* 6px */
  text-align: center;
  box-shadow: var(--shadow-lg); /* 2px 6px 12px rgba(0,0,0,0.16) */
}

.loading-spinner-large {
  width: 40px;
  height: 40px;
  border-width: 4px;
}

.loading-card .loading-text {
  margin-top: 16px;
  font-size: 14px;
  color: var(--color-gray-d50); /* #333333 */
}
```

---

## 状态 States

### 加载指示器颜色

| 状态 | 边框色 | 顶部色 | 说明 |
|------|--------|--------|------|
| 默认 | Gray.l20 | poseidonBlue.default | 正常加载中 |
| 白色 | rgba(255,255,255,0.3) | Gray.l60 | 深色背景上使用 |

```css
/* 深色背景使用 */
.loading-spinner-inverse {
  border-color: rgba(255, 255, 255, 0.3);
  border-top-color: var(--color-gray-l60);
}
```

### 加载文案状态

| 状态 | 文字色 | 说明 |
|------|--------|------|
| 加载中 | Gray.d40 | 显示加载文案 |
| 成功 | belarusGreen.default | 加载完成（可选） |
| 失败 | classicalRed.default | 加载失败（可选） |

---

## 功能 Features

### 1. 按钮加载

```css
/* 按钮内加载 */
.btn-loading {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  pointer-events: none;
}

.btn-loading .loading-spinner {
  width: 14px;
  height: 14px;
  border-width: 2px;
}
```

### 2. 区域加载

```css
/* 卡片区域加载 */
.loading-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 120px;
  gap: 12px;
}
```

### 3. 骨架屏加载

见 [骨架屏组件](./骨架屏-Skeleton.md)

---

## 变体 Variants

### 1. 圆形加载

```css
.loading-spinner-circle {
  border-radius: 50%;
}
```

### 2. 条形加载

```css
.loading-bar {
  width: 100%;
  height: 4px;
  background: var(--color-gray-l20);
  overflow: hidden;
}

.loading-bar-progress {
  height: 100%;
  background: var(--color-poseidon-blue-default);
  animation: loading-bar-animation 1.5s ease-in-out infinite;
}

@keyframes loading-bar-animation {
  0% { width: 0%; }
  50% { width: 70%; }
  100% { width: 100%; }
}
```

### 3. 圆点加载

```css
.loading-dots {
  display: flex;
  gap: 4px;
}

.loading-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--color-poseidon-blue-default);
  animation: dot-bounce 1.4s ease-in-out infinite;
}

.loading-dot:nth-child(2) {
  animation-delay: 0.2s;
}

.loading-dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes dot-bounce {
  0%, 80%, 100% { transform: scale(0.6); }
  40% { transform: scale(1); }
}
```

---

## 使用示例

### 按钮加载

```html
<button class="btn btn-primary btn-loading">
  <span class="loading-spinner"></span>
  <span>提交中...</span>
</button>
```

### 区域加载

```html
<div class="loading-area">
  <div class="loading-spinner"></div>
  <span class="loading-text">正在加载数据...</span>
</div>
```

### 全屏加载

```html
<div class="loading-fullscreen">
  <div class="loading-card">
    <div class="loading-spinner-large"></div>
    <p class="loading-text">正在加载...</p>
  </div>
</div>
```

---

## 关联文档

- [骨架屏](./骨架屏-Skeleton.md)
- [按钮](./按钮-Button.md)
- [动画规范](../../design-system.md)