---
name: "云BG设计规范-基础组件-图片预览（Image）"
description: "提供图片预览组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现图片预览组件时调用。"
step:
  1. 需求解析：理解用户需要的预览类型（缩略图/灯箱预览/画廊预览）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 图片预览 Image

## 概述

图片预览组件用于展示、缩略、预览图片资源，支持多种预览模式和交互。

- **来源**：深信服云BG设计部
- **类型**：数据展示组件
- **适用场景**：图片列表、商品图册、文档预览、头像编辑

## 使用场景

图片预览组件适用于以下情况：

- **图片列表**：多图片网格展示
- **商品图册**：产品图片轮播
- **文档预览**：PDF、图片文件预览
- **头像编辑**：用户头像裁剪预览

## 设计规范

### 尺寸规范

#### 缩略图尺寸

| 尺寸 | 尺寸 | 适用场景 |
|------|------|----------|
| 小 sm | 64px | 图标级缩略图 |
| 默认 md | 96px | 标准缩略图 |
| 大 lg | 128px | 详情预览 |
| 特大 xl | 192px | 大图预览 |

#### 预览容器

| 类型 | 尺寸 | 说明 |
|------|------|------|
| 灯箱预览 | 全屏 100vw × 100vh | 模态遮罩 |
| 画廊模式 | 屏幕 80% | 多图切换 |

### 组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Image | 图片主容器 | 必需 |
| ImageThumb | 缩略图 | 必需 |
| ImagePreview | 预览区域 | 可选 |
| ImageMask | 悬浮遮罩 | 可选 |
| ImageViewer | 全屏查看器 | 可选 |
| ImagePlaceholder | 占位图 | 可选 |

### 形状规范

| 形状 | 圆角 | 适用场景 |
|------|------|----------|
| 方形 | 0 | 文档缩略图 |
| 小圆角 | 4px | 标准图片 |
| 大圆角 | 8px | 头像卡片 |
| 圆形 | 50% | 头像类图片 |

### 颜色规范

| 元素 | 颜色 | Token |
|------|------|-------|
| 背景 | Gray.l60 | `var(--color-gray-l60)` |
| 边框 | Gray.l20 | `var(--color-gray-l20)` |
| 遮罩背景 | rgba(0,0,0,0.5) | - |
| 操作图标 | #FFFFFF | - |
| 加载占位 | Gray.l30 | `var(--color-gray-l30)` |

### 状态规范

| 状态 | 样式描述 |
|------|----------|
| 默认 | 显示缩略图 |
| 悬浮 | 显示遮罩和操作按钮 |
| 加载中 | 显示骨架屏占位 |
| 加载失败 | 显示错误图标和重试按钮 |
| 预览中 | 显示全屏预览 |

### 交互规范

| 交互 | 行为 |
|------|------|
| 点击缩略图 | 打开预览模式 |
| 悬浮缩略图 | 显示遮罩和放大图标 |
| 预览内点击 | 关闭预览 |
| ESC 键 | 关闭预览 |
| 拖拽图片 | 缩放预览图片 |

## 代码示例

### 基础图片

```html
<div class="image image-md">
  <img src="..." alt="图片描述" />
</div>
```

### 带操作图片

```html
<div class="image image-thumb image-lg">
  <img src="..." alt="图片描述" />
  <div class="image-mask">
    <span class="image-action">
      <i class="iconfont icon-zoom-in"></i>
    </span>
  </div>
</div>
```

### 样式代码

```css
/* 图片容器 */
.image {
  display: inline-block;
  position: relative;
  overflow: hidden;
  border-radius: 4px;
  background-color: var(--color-gray-l60);
  border: 1px solid var(--color-gray-l20);
}

/* 尺寸 */
.image-sm { width: 64px; height: 64px; }
.image-md { width: 96px; height: 96px; }
.image-lg { width: 128px; height: 128px; }
.image-xl { width: 192px; height: 192px; }

/* 图片填充 */
.image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* 悬浮遮罩 */
.image-mask {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 0;
  transition: opacity 0.2s;
  cursor: pointer;
}

.image:hover .image-mask {
  opacity: 1;
}

/* 操作按钮 */
.image-action {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  color: var(--color-gray-d50);
}

.image-action:hover {
  background-color: #FFFFFF;
}

/* 加载占位 */
.image-placeholder {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: var(--color-gray-l30);
  color: var(--color-gray-d30);
}

/* 全屏预览 */
.image-viewer {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.85);
}

.image-viewer img {
  max-width: 90%;
  max-height: 90%;
  object-fit: contain;
}

.image-viewer-close {
  position: absolute;
  top: 24px;
  right: 24px;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  color: #FFFFFF;
  cursor: pointer;
}
```

## 最佳实践

### DO

- 使用 `object-fit` 保持比例
- 提供加载状态占位
- 支持键盘操作（ESC 关闭）
- 保持预览图片质量

### DON'T

- 避免拉伸变形
- 不要缺少 alt 文本
- 避免加载时显示空白
- 不要使用过大的原图
