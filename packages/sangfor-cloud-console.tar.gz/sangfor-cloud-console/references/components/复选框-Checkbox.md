---
name: "云BG设计规范-基础组件-复选框（checkbox）"
description: "提供复选框组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现复选框组件时调用。"
step:
  1. 需求解析：理解用户需要创建的复选框类型（基础复选框、按钮复选框）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 复选框 Checkbox

## 概述

### 功能描述

复选框用于在一组可选项中进行多项选择时，单个复选框可以表示两种状态之间的切换。

- **来源**：深信服云BG设计部
- **类型**：表单组件
- **适用场景**：多项选择、状态切换、全选操作

### 分类及组成元素

| 分类 | 组成元素 | 说明 | 使用位置 |
|------|------|----------|----------|
| 基础复选框 | 方形选择框 + 子选项面板（可选） + 标签文字 | 默认分类，最基础的复选框形式，多项选择、全选、状态启用 | 工具栏、表单、表格、选择器及其他组件 |
| 按钮复选框 | 选择按钮 | 多项选择场景，常用于列表选项筛选且需要同时选中多个筛选项的场景 | 筛选栏、工具栏，适用于选项较短、需要突出显示、存在频繁变更的场景 |

## 设计规范

### 基础复选框设计规范

**方形选择框组成说明**
- 外框：方形选择框所在的方形区域
- 内框：方形选择框填充区域，用于显示对勾图标
- 对勾图标：选中状态的对勾图标，用于表示已选择的选项
- 半选图标：半选状态的对勾图标，用于表示部分选中的选项

#### 尺寸规范

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 外框 | 16px × 16px | 复选框外框尺寸 |
| 内框 | 14px × 14px | 复选框内框填充区域尺寸 |
| 圆角 | 2px | 复选框圆角 |
| 对勾图标 | 10px × 8px | 选中状态的对勾图标尺寸 |
| 图标与文字间距 | 4px | 复选框图标与文字之间的间距 |
| 复选框组间距 | 24px | 多个复选框成组时，各选项之间的横向间距 |

#### 组件结构

推荐将复选框组件拆分为以下稳定、可复用的子结构：

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Checkbox | 复选框主容器 | 必需 |
| CheckboxInput | 复选框输入元素 | 必需 |
| CheckboxLabel | 复选框标签文字 | 可选 |
| CheckboxGroup | 复选框组容器 | 必需 |
| CheckboxIndeterminate | 半选状态 | 可选 |

#### 颜色规范（差异标记法）

**基础样式（默认状态）**

| 元素 | 未选中 | 已选中 | 半选 |
|------|--------|--------|------|
| 填充 | var(--color-gray-l60) | var(--color-poseidon-blue-default) | var(--color-poseidon-blue-default) |
| 边框 | var(--color-blue-gray-default) 1px | var(--color-poseidon-blue-default) 1px | var(--color-poseidon-blue-default) 1px |
| 图标 | - | var(--color-gray-l60) | var(--color-gray-l60) |
| 文字 | var(--color-gray-d50) | var(--color-gray-d50) | var(--color-gray-d50) |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中变化 | 已选中变化 | 半选变化 |
|------|-----------|-----------|---------|
| 悬浮 | 边框→poseidon-blue-default | - | - |
| 点击 | 边框→poseidon-blue-default | - | - |
| 聚焦 | +内描边blue-gray-default，+外描边poseidon-blue-default | +外描边poseidon-blue-default | +外描边poseidon-blue-default |
| 禁用 | 填充→gray-l20，文字→gray-d20 | 填充→gray-l20，边框→blue-gray-default，图标→blue-gray-default，文字→gray-d20 | 填充→gray-l20，边框→blue-gray-default，图标→blue-gray-default，文字→gray-d20 |

- **注意**：禁用状态下，方形选择框禁止加透明度

**错误状态**

| 元素 | Token |
|------|-------|
| 错误边框 | var(--color-classical-red-default) 1px |

#### 基础单选框组排列说明

- 由至少 2 个基础复选框组成，默认为横向排布
- **等间距排列**：一行单选框优先使用等间距排列，间距固定为 24px
- **等宽排列**：多行单选框建议使用等宽排列，此时栏间距为 16px。当单选框字段长度不一致时，采用等宽排列可确保列对齐整齐，每行单选框左对齐，列宽均分，视觉呈现规整的网格布局

#### 子选项面板 (Sub-options Panel)

**定义**：承载复选框选项的扩展说明、配置项或关联表单的折叠式内容容器。

**核心特征**：
- 与复选框选项绑定，默认展开不支持收起
- 可包含文本说明或子表单控件

**位置**：面板不是以浮层的形式展示，而是直接在复选框下方展示，与复选框左侧对齐
**箭头**：面板的箭头指向基础复选框方形选择框的中间位置

**布局规范**

| 属性 | 规格 | 说明 |
|------|------|------|
| 对齐方式 | 面板左边缘与复选框组第一个选项左对齐 | 确保视觉层级清晰 |
| 指示器箭头 | 指向当前复选框方形选择框的中心 | 明确指示内容归属 |
| 面板间距 | 与复选框组间距 8px | 保持呼吸感 |

**视觉样式**

| 属性 | 规格 |
|------|------|
| 内边距 | 上下 2px，左右 8px |
| 背景色 | var(--color-blue-gray-l50) |
| 边框 | 1px solid var(--color-blue-gray-l10) |
| 圆角 | 4px |
| 最大宽度 | 480px（自适应） |
| 箭头尺寸 | 8px 等腰三角形 |

**箭头位置规范**

- **指向目标**：箭头尖端指向复选框方形选择框的中心
- **视觉要求**：箭头垂直中线与方形选择框垂直中线对齐，允许误差不超过 2px
- **动态跟随**：切换选中项时，箭头应平滑移动至新选项位置

> 实现提示：可通过 JavaScript 动态计算方形选择框中心位置，或使用 CSS 预设位置。

**行为规则**

1. **内容推移**：面板展开时向下推移下方内容，避免遮挡用户操作
2. **溢出处理**：面板内容超出最大高度时可内部滚动
3. **状态联动**：选中复选框时，面板内容为启用状态；未选中时，面板内容为禁用状态

**可访问性 (ARIA)**

| 属性 | 值 | 说明 |
|------|-----|------|
| role | region | 标识为独立区域 |
| aria-labelledby | 触发选项ID | 关联触发选项 |
| aria-expanded | true/false | 展开状态 |
| aria-live | polite | 展开时通知读屏软件 |

### 按钮复选框设计规范

| 属性 | 说明 |
|------|------|
| 组成数量 | 至少包含 2 个选择按钮 |
| 整齐排列 | 按钮之间间距为 8px |
| 选中状态 | 支持多个按钮同时选中 |

#### 颜色规范（差异标记法）

**基础样式（默认状态）**

| 组成元素 | 未选中 | 选中 |
|----------|--------|------|
| 填充 | var(--color-gray-l60) | var(--color-gray-l60) |
| 描边 | var(--color-blue-gray-default) 1px | var(--color-poseidon-blue-default) 1px |
| 字体 | var(--color-gray-d50) | var(--color-poseidon-blue-default) |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中变化 | 选中变化 |
|------|-----------|---------|
| 悬浮 | 描边→blue-gray-d20，字体→gray-d60 | - |
| 点击 | 描边→poseidon-blue-l20，字体→gray-d60 | - |
| 禁用 | 透明度40% | 透明度40% |

## 常见问题

**Q: 为什么基础选择框禁用状态的已选/半选方形框仍然显示蓝色？**

**A:** 这是 CSS 选择器优先级问题导致的。

**问题原因：**
- 已选状态的选择器：`input[type="checkbox"]:checked + .checkbox-label .checkbox-box`
- 禁用状态的选择器：`.checkbox-wrapper.disabled .checkbox-box`
- 由于 `:checked` 伪类的优先级高于 `.disabled` 类选择器，导致禁用状态的灰色样式被蓝色覆盖

**解决方案：**
```css
/* 提高禁用状态选择器优先级，覆盖已选和半选 */
.checkbox-wrapper.disabled .checkbox-box,
.checkbox-wrapper.disabled input[type="checkbox"]:checked + .checkbox-label .checkbox-box,
.checkbox-wrapper.disabled input[type="checkbox"]:indeterminate + .checkbox-label .checkbox-box {
  background: var(--color-gray-l20);
  border-color: var(--color-blue-gray-default);
}
```

**关键点：**
1. 必须显式写出 `:checked` 和 `:indeterminate` 的禁用场景
2. 禁止使用 `opacity` 透明度来简化实现，会导致颜色偏差
3. 图标颜色（对勾/半选横线）也需要单独处理成灰色


## 关联文档

- [颜色系统](../../design-system.md)
- [图标系统](../../design-system.md)
