---
name: "云BG设计规范-基础组件-头像（Avatar）"
description: "提供头像组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现头像组件时调用。"
step:
  1. 需求解析：理解用户需要的头像类型（用户头像/群组头像/图标头像）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 头像 Avatar

## 概述

头像用于展示用户或实体的图片、图标，是身份识别的视觉元素。

- **来源**：深信服云BG设计部
- **类型**：数据展示组件
- **适用场景**：用户信息展示、评论头像、成员列表、消息列表

## 使用场景

头像组件适用于以下情况：

- **用户信息**：个人资料页、用户卡片
- **消息列表**：聊天消息、通知消息
- **成员管理**：团队成员、联系人列表
- **评论系统**：文章评论、帖子回复

## 设计规范

### 尺寸规范

| 尺寸 | 尺寸 | 适用场景 |
|------|------|----------|
| 超小 xs | 24px | 内联文本、表格行内 |
| 小 sm | 32px | 消息列表、评论列表 |
| 默认 md | 40px | 标准列表、卡片 |
| 大 lg | 56px | 用户卡片、详情页 |
| 特大 xl | 80px | 个人资料、头部区域 |
| 超大 xxl | 120px | 全屏展示、头像墙 |

### 形状规范

| 形状 | 圆角 | 适用场景 |
|------|------|----------|
| 圆形 | 50% | 用户头像、人物头像 |
| 圆角方形 | 4px | 群组头像、系统图标 |
| 方形 | 0 | 特殊场景 |

### 组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Avatar | 头像主容器 | 必需 |
| AvatarImage | 头像图片 | 可选 |
| AvatarText | 头像文字 | 可选 |
| AvatarGroup | 头像组 | 可选 |
| AvatarBadge | 头像徽章 | 可选 |

### 颜色规范

| 状态 | 背景色 | 文字色 | Token |
|------|--------|--------|-------|
| 默认（图片） | - | - | - |
| 默认（文字） | poseidonBlue.l40 | poseidonBlue.default | `var(--color-poseidon-blue-l40)` |
| 悬浮 | poseidonBlue.l30 | poseidonBlue.d10 | - |
| 选中 | poseidonBlue.l20 | poseidonBlue.d20 | - |
| 离线状态 | Gray.l40 | Gray.d40 | - |
| 在线状态 | belarusGreen.default | #FFFFFF | `var(--color-belarus-green-default)` |

### 头像组规范

| 属性 | 规范 |
|------|------|
| 叠加方向 | 从左到右 |
| 叠加间距 | -8px（重叠部分） |
| 最大显示数量 | 5个 |
| 溢出显示 | +N 样式 |
| 最大宽度 | 头像尺寸 × 1.5 |

### 文字头像规范

| 姓名字数 | 显示规则 |
|----------|----------|
| 1个字 | 完整显示 |
| 2个字 | 各取一半 |
| 3个字 | 首字 + 末字 |
| 4个字及以上 | 首2字各取一半 |

## 代码示例

### 基础头像

```html
<!-- 图片头像 -->
<div class="avatar avatar-md">
  <img src="..." alt="用户头像" />
</div>

<!-- 文字头像 -->
<div class="avatar avatar-md avatar-text">
  <span>李明</span>
</div>
```

### 头像组

```html
<div class="avatar-group">
  <div class="avatar avatar-sm">...</div>
  <div class="avatar avatar-sm">...</div>
  <div class="avatar avatar-sm avatar-overflow">+5</div>
</div>
```

### 样式代码

```css
/* 头像容器 */
.avatar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  overflow: hidden;
  background-color: var(--color-poseidon-blue-l40);
  color: var(--color-poseidon-blue-default);
  font-weight: 500;
}

/* 尺寸 */
.avatar-xs { width: 24px; height: 24px; font-size: 10px; }
.avatar-sm { width: 32px; height: 32px; font-size: 12px; }
.avatar-md { width: 40px; height: 40px; font-size: 14px; }
.avatar-lg { width: 56px; height: 56px; font-size: 18px; }
.avatar-xl { width: 80px; height: 80px; font-size: 24px; }
.avatar-xxl { width: 120px; height: 120px; font-size: 36px; }

/* 文字头像 */
.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* 头像组 */
.avatar-group {
  display: flex;
  flex-direction: row-reverse;
}

.avatar-group .avatar {
  margin-left: -8px;
  border: 2px solid #FFFFFF;
}

.avatar-group .avatar:last-child {
  margin-left: 0;
}

.avatar-overflow {
  background-color: var(--color-gray-l30);
  color: var(--color-gray-d50);
  font-size: 12px;
}

/* 状态指示器 */
.avatar-status {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 25%;
  height: 25%;
  border-radius: 50%;
  border: 2px solid #FFFFFF;
  background-color: var(--color-belarus-green-default);
}
```

## 最佳实践

### DO

- 始终提供 alt 文本
- 使用 `object-fit: cover` 保持比例
- 头像组保持一致的叠加顺序
- 提供加载失败时的占位图

### DON'T

- 避免拉伸或变形
- 不要在头像上叠加过多元素
- 避免在 xs 尺寸添加徽章
- 不要使用不清晰的低分辨率图片
