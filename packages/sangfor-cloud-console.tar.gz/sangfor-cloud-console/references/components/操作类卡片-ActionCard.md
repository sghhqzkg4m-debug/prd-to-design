---
name: "云BG设计规范-基础组件-操作类卡片"
description: "提供操作类卡片（单选/多选/可添加）的设计规范、交互状态与最佳实践。当用户需要实现选择操作场景的卡片组件时调用。基础外框样式由本文件定义，展示类卡片引用此外框规范。"
step:
  1. 需求解析：判断操作类型（单选/多选/可添加），确定外框样式（投影/描边）和布局方式（无标题/有标题）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码

ai_instructions:
  icon_usage_rules:
    - "必须使用本文档指定的图标类名，严禁使用其他图标替代"
    - "图标前缀统一为 vtv-icon-"
    - "严禁根据语义自行搜索图标，必须按清单使用"
  forbidden_substitutions:
    - "未选复选框：必须使用 vtv-icon-comp-ok-border，严禁使用 checkbox、checkbox-unchecked、square 等"
    - "选中复选框：必须使用 vtv-icon-comp-ok-circle，严禁使用 checkbox-checked、check、tick、selected 等"
    - "+ 号图标：必须使用 vtv-icon-plus-small，严禁使用 vtv-icon-add、vtv-icon-plus 等通用图标"
  checklist_before_generate:
    - "确认所有图标类名与图标清单一致"
    - "确认图标前缀为 vtv-icon-"
    - "确认没有使用任何通用图标替代组件专用图标"
---

> ⚠️ **图标使用强制声明**：本组件所有图标必须使用下表指定的图标类名，**严禁**使用 `checkbox`、`check`、`tick`、`selected`、`square`、`add`、`plus` 等通用图标替代。

## 图标清单（强制）

| 位置 | 图标类名 | 尺寸 | 颜色 | 严禁使用 |
|------|----------|------|------|----------|
| 未选复选框 | `vtv-icon-comp-ok-border` | 14px | `blueGray.default` | `checkbox`, `checkbox-unchecked`, `square`, `unchecked` |
| 选中复选框 | `vtv-icon-comp-ok-circle` | 14px | `poseidonBlue.default` | `checkbox-checked`, `check`, `tick`, `selected`, `checked` |
| + 号 | `vtv-icon-plus-small` | 24px | 随状态变化 | `vtv-icon-add`, `vtv-icon-plus`, `vtv-icon-create` |

## 常见错误与正确用法

| 场景 | ❌ 错误用法 | ✅ 正确用法 | 说明 |
|------|------------|------------|------|
| 多选-未选 | `vtv-icon-checkbox` | `vtv-icon-comp-ok-border` | 必须使用组件专用复选框图标 |
| 多选-选中 | `vtv-icon-check` | `vtv-icon-comp-ok-circle` | 必须使用筛选-选中图标 |
| 可添加-加号 | `vtv-icon-add` | `vtv-icon-plus-small` | 必须使用 plus-small 图标 |
| 通用选中 | `vtv-icon-tick` | `vtv-icon-comp-ok-circle` | 严禁使用 tick/check 等通用图标 |

# 操作类卡片

## 概述

操作类卡片用于**选择操作场景**（如编辑页配置选择、资源选择等），具有完整的交互状态。用户通过点击整个卡片完成选择，卡片本身即操作触发器，不需要外置操作区按钮。

- **来源**：深信服云BG设计部
- **类型**：容器组件 — 交互型
- **适用场景**：单选配置、多选资源、添加新项等可选操作场景

## 使用场景

### 何时使用

- **配置选择**：编辑页面中的配置项选择
- **资源选择**：资源池、实例等对象的选择
- **添加新项**：引导用户添加新卡片占位

### 何时不用

- 仅作信息展示而无选择操作 — 使用展示类卡片
- 信息量少且简单 — 使用单选框/复选框等基础表单组件

---

## 组件构成

操作类卡片由以下部分组成：

| # | 区域 | 是否必需 | 说明 |
|---|------|---------|------|
| ① | **卡头** | 可选 | 表明卡片主题；**大多场景不带标题**，仅在内容复杂、需要分区说明时使用。字号、字重、行高参考「14号标题栏」规范；卡头与内容区之间默认无分隔线，详见 [标题栏-Title.md](./标题栏-Title.md) |
| ② | **内容区** | 必需 | 卡片核心内容区域 |
| ③ | **外框** | 必需 | 分为投影和描边两种样式，根据页面背景选择，详见「基础样式」章节 |

> 操作类卡片**无外置操作区** — 整个卡片即操作触发器。

---

## 布局规范

### 无标题布局（默认）

内容区占满卡片，四边统一内边距 **16px**，无卡头。**大多操作类卡片使用此布局**。

```
┌─────────────────────────────────┐
│ [16px]                          │
│           内容区                 │
│ [16px]                          │
└─────────────────────────────────┘
```

**何时使用：**
- 内容简单、卡片用途从上下文可直接判断
- 单选 / 多选 / 可添加卡片在内容简单时使用此布局

### 有标题布局

上方有卡头。卡头与内容区之间默认无分隔线，通过留白区分。

```
┌─────────────────────────────────────┐
│  卡头：标题                          │ ← 40px
├─────────────────────────────────────┤
│ [8px]                               │
│           内容区                     │
│ [16px]                              │
└─────────────────────────────────────┘
```

**何时使用：**
- 内容复杂，需要通过标题标注主题
- 单选 / 多选卡片在内容复杂、需要分区说明时使用此布局

**有标题布局内容区边距：**

| 方向 | 值 | 说明 |
|------|----|------|
| 上 | 8px | 卡头与内容区之间的留白 |
| 左/右 | 16px | 与卡头左右内边距一致 |
| 下 | 16px | 内容区与卡片底部之间 |

---

## 基础样式

基础样式定义卡片外框的默认视觉规范，**不包含交互状态**。操作类卡片和展示类卡片均引用此规范，根据页面背景选择投影或描边。

### 投影卡片

**适用背景**：灰色背景页面，通过阴影与页面背景形成层级区分。

| 属性 | Token | 值 |
|------|-------|----|
| 背景色 | `Gray.l60` | #FFFFFF |
| 边框 | — | 无 |
| 阴影 | `shadow.md` | 0px 1px 4px 0px rgba(0,0,0,0.08) |
| 圆角 | `radius.xs` | 2px |

### 描边卡片

**适用背景**：白色背景页面，或嵌套在白色容器中，通过描边与底部白卡片形成层级区分。

| 属性 | Token | 值 |
|------|-------|----|
| 背景色 | `Gray.l60` | #FFFFFF |
| 边框 | `blueGray.default` | 1px solid |
| 阴影 | 无 | — |
| 圆角 | `radius.xs` | 2px |

---

## 交互状态规范

操作类卡片在基础样式（投影 / 描边）之上叠加以下状态规范。

### 单选卡片

用于只能选择一个卡片的场景，点击即选中，互斥。

#### 投影样式 × 单选

| 状态 | 背景色 | 边框 | 阴影 |
|------|--------|------|------|
| 默认 | `Gray.l60` | 无 | `shadow.md` |
| 悬浮 | `Gray.l60` | `poseidonBlue.l20` 2px solid | `shadow.md` |
| 点击 | `Gray.l60` | `poseidonBlue.d10` 2px solid | `shadow.md` |
| 选中 | `Gray.l60` | `poseidonBlue.l20` 2px solid | `shadow.md` |
| 禁用 | `Gray.l60` | 无（整体透明度 40%） | `shadow.md` |

#### 描边样式 × 单选

| 状态 | 背景色 | 边框 |
|------|--------|------|
| 默认 | `Gray.l60` | `blueGray.default` 1px solid |
| 悬浮 | `Gray.l60` | `poseidonBlue.l20` 1px solid |
| 点击 | `Gray.l60` | `poseidonBlue.d10` 1px solid |
| 选中 | `poseidonBlue.l70` | `poseidonBlue.l20` 1px solid |
| 禁用 | `Gray.l60` | `blueGray.default` 1px solid（整体透明度 40%） |

---

### 多选卡片

用于可以选择多个卡片的场景，右上角显示复选框图标，图标随状态变化。

#### 投影样式 × 多选

| 状态 | 背景色 | 边框 | 阴影 | 复选框图标 |
|------|--------|------|------|------------|
| 默认 | `Gray.l60` | 无 | `shadow.md` | 隐藏 |
| 悬浮 | `Gray.l60` | `poseidonBlue.l20` 2px solid | `shadow.md` | `vtv-icon-comp-ok-border`，色：`blueGray.default` |
| 点击 | `Gray.l60` | `poseidonBlue.d10` 2px solid | `shadow.md` | `vtv-icon-comp-ok-circle`，色：`poseidonBlue.l20` |
| 选中 | `Gray.l60` | `poseidonBlue.l20` 2px solid | `shadow.md` | `vtv-icon-comp-ok-circle`，色：`poseidonBlue.default` |
| 禁用 | `Gray.l60` | 无（整体透明度 40%） | `shadow.md` | 隐藏 |

#### 描边样式 × 多选

| 状态 | 背景色 | 边框 | 复选框图标 |
|------|--------|------|------------|
| 默认 | `Gray.l60` | `blueGray.default` 1px solid | 隐藏 |
| 悬浮 | `Gray.l60` | `poseidonBlue.l20` 1px solid | `vtv-icon-comp-ok-border`，色：`blueGray.default` |
| 点击 | `Gray.l60` | `poseidonBlue.d10` 1px solid | `vtv-icon-comp-ok-circle`，色：`poseidonBlue.l20` |
| 选中 | `poseidonBlue.l70` | `poseidonBlue.l20` 1px solid | `vtv-icon-comp-ok-circle`，色：`poseidonBlue.default` |
| 禁用 | `Gray.l60` | `blueGray.default` 1px solid（整体透明度 40%） | 隐藏 |

**复选框图标规范：**

> 图标引用自 [图标系统](../../design-system.md)

| 属性 | 值 |
|------|----|
| 尺寸 | 14px × 14px |
| 位置 | 右上角：顶部 7px、右侧 7.6px |
| 未选图标 | `vtv-icon-comp-ok-border` |
| 选中图标 | `vtv-icon-comp-ok-circle` |

---

### 可添加卡片

用于添加新卡片的占位场景，带 + 号图标引导用户操作。无「选中后保持」状态的背景变化，共 5 种状态。

投影样式与描边样式的**关键区别**：投影样式所有状态均无边框，通过阴影与 + 号颜色变化体现交互；描边样式各状态保持虚线边框，通过边框颜色变化体现交互。

#### 投影样式 × 可添加

| 状态 | 背景色 | 边框 | 阴影 | + 号颜色 |
|------|--------|------|------|---------|
| 默认 | `Gray.l60` | 无 | `shadow.md` | `blueGray.default` |
| 悬浮 | `Gray.l60` | 无 | `shadow.md` | `graphiteBlack.l30` |
| 点击 | `Gray.l60` | 无 | `shadow.md` | `poseidonBlue.d10` |
| 选中 | `Gray.l60` | 无 | `shadow.md` | `poseidonBlue.default` |
| 禁用 | `Gray.l60` | 无（整体透明度 40%） | `shadow.md` | `blueGray.default` |

#### 描边样式 × 可添加

| 状态 | 背景色 | 边框 | + 号颜色 |
|------|--------|------|---------|
| 默认 | `Gray.l60` | `blueGray.default` 1px dashed | `blueGray.default` |
| 悬浮 | `Gray.l60` | `blueGray.d30` 1px dashed | `graphiteBlack.l30` |
| 点击 | `Gray.l60` | `poseidonBlue.d10` 1px dashed | `poseidonBlue.d10` |
| 选中 | `Gray.l60` | `poseidonBlue.l20` 1px dashed | `poseidonBlue.default` |
| 禁用 | `Gray.l60` | `blueGray.default` 1px dashed（整体透明度 40%） | `blueGray.default` |

**+ 号图标规范：**

> 图标引用自 [图标系统](../../design-system.md)

| 属性 | 值 |
|------|----|
| 图标 | `vtv-icon-plus-small` |
| 尺寸 | 24px × 24px |
| 颜色 | 随状态变化（见上表） |

---

## 尺寸规范

### 内边距规范

| 尺寸 | Token | 值 | 适用场景 |
|------|-------|----|----------|
| Padding-M | `padding.m` | 16px | 操作类卡片默认内边距 |

### 圆角规范

> 引用自 [圆角系统](../../design-system.md)

| 元素 | Token | 值 |
|------|-------|----|
| 卡片容器 | `radius.xs` | 2px |

### 阴影规范

> 引用自 [阴影系统](../../design-system.md)

投影卡片所有状态使用相同阴影，状态变化仅通过边框颜色体现。

| Token | 值 |
|-------|----|
| `shadow.md` | 0px 1px 4px 0px rgba(0,0,0,0.08) |

---

## 样式实现要点

> 所有样式必须使用本文档中定义的 Token（或全局 CSS 变量）引用，禁止硬编码具体值。

**基础外框：**
- 投影卡片使用 `shadow.md` + `Gray.l60` 背景 + `radius.xs` 圆角
- 描边卡片使用 `blueGray.default` 边框 + `Gray.l60` 背景 + `radius.xs` 圆角

**操作类卡片防抖动：**
- 投影样式的单选/多选卡片，默认使用 `2px solid transparent` 边框占位，状态变化时仅改边框颜色、不改宽度，避免布局抖动
- 描边样式选中时背景变为 `poseidonBlue.l70`

**复选框图标显隐：**
- 默认状态隐藏，悬浮和选中状态显示，禁用状态隐藏

**卡头规范（有标题布局时）：**
- 卡头高度 40px，左右内边距 16px，字号 14px/500/20px，颜色 `Gray.d60`
- 卡头与内容区之间默认无分隔线，通过留白区分
- 有标题布局时内容区上内边距 8px，左/右/下内边距 16px

---

## 使用规范

### 命名规范

| 类型 | 命名（原子类组合） |
|------|-------------------|
| 投影卡片 | `card-shadow` |
| 描边卡片 | `card-outline` |
| 单选卡片 | `card-shadow card-selectable` / `card-outline card-selectable` |
| 多选卡片 | `card-shadow card-multi` / `card-outline card-multi` |
| 可添加卡片 | `card-shadow card-add` / `card-outline card-add` |

### 避免事项

- 不要在同一页面混用投影和描边卡片
- 单选和多选卡片不要混用
- 禁用状态下不应有交互反馈

---

## 关联文档

- [展示类卡片](./展示类卡片-DisplayCard.md) — 引用本文件定义的基础外框样式
- [标题栏-Title.md](./标题栏-Title.md) — 卡头字号/字重/行高参考 14号标题栏规范
- [颜色系统](../../design-system.md)
- [圆角系统](../../design-system.md)
- [阴影系统](../../design-system.md)
