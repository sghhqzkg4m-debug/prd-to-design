---
name: "云BG设计规范-基础组件-数字输入框（input-number）"
description: "提供数字输入框组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现数字输入框组件时调用。"
step:
  1. 需求解析：理解用户需要创建的数字输入框类型（基础数字输入/带步进按钮/小数输入/整数输入）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 数字输入框 InputNumber

## 概述

数字输入框是用于输入数字值的专用输入组件，支持数值加减、步进控制、格式化和范围限制，常用于数量、价格等数值输入场景。

- **来源**：深信服云BG设计部
- **类型**：表单组件
- **适用场景**：数量输入、价格输入、参数配置、规格设置

## 使用场景

数字输入框组件适用于以下情况：

- **数量输入**：商品数量、采购数量
- **价格输入**：商品价格、费用金额
- **参数配置**：时间间隔、百分比设置
- **规格设置**：尺寸、数量限制
- **百分比输入**：进度、比例配置

## 组件结构

### 子组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| InputNumber | 数字输入框主容器 | 必需 |
| InputNumberInput | 数字输入框主体 | 必需 |
| InputNumberControls | 步进控制按钮组 | 可选 |
| InputNumberDecrease | 减少按钮 | 可选 |
| InputNumberIncrease | 增加按钮 | 可选 |
| InputNumberPrefix | 前缀区域 | 可选 |
| InputNumberSuffix | 后缀区域 | 可选 |

## 尺寸规范

### 常规尺寸

| 属性 | Small | Default | Large |
|------|-------|---------|-------|
| 高度 | 24px | 32px | 40px |
| 宽度 | 80px | 120px | 160px |
| 内边距 | 0 8px | 0 12px | 0 16px |
| 字体大小 | 12px | 14px | 16px |
| 圆角 | 4px | 4px | 4px |

### 步进按钮

| 属性 | Small | Default | Large |
|------|-------|---------|-------|
| 按钮宽度 | 20px | 24px | 28px |
| 按钮高度 | 100% | 100% | 100% |
| 图标大小 | 12px | 14px | 16px |
| 按钮间距 | 1px | 1px | 1px |

## 颜色规范

### 输入框颜色

| 状态 | 边框色 | 背景色 | 文字色 |
|------|--------|--------|--------|
| 默认 | `blueGray.default` | `Gray.l60` | `Gray.d50` |
| 悬浮 | `blueGray.d20` | `Gray.l60` | `Gray.d50` |
| 聚焦 | `poseidonBlue.default` | `Gray.l60` | `Gray.d50` |
| 禁用 | `blueGray.default` | `Gray.l30` | `Gray.d30` |
| 错误 | `classicalRed.default` | `Gray.l60` | `Gray.d50` |

### 步进按钮颜色

| 状态 | 按钮背景 | 图标色 |
|------|----------|--------|
| 默认 | `Gray.l40` | `Gray.d50` |
| 悬浮 | `poseidonBlue.l20` | `poseidonBlue.default` |
| 禁用 | `Gray.l30` | `Gray.d30` |

### 边界状态

| 状态 | 提示 | 样式变化 |
|------|------|----------|
| 达到最小值 | 减少按钮禁用 | 按钮变灰 |
| 达到最大值 | 增加按钮禁用 | 按钮变灰 |

## 交互规范

### 状态定义

| 状态 | 表现 | 说明 |
|------|------|------|
| 默认 | 边框 `blueGray.default` | 静止状态 |
| 悬浮 | 边框 `blueGray.d20` | 鼠标悬停 |
| 聚焦 | 蓝色边框 + 阴影 | 输入激活 |
| 禁用 | 灰色背景 + 禁用光标 | 不可编辑 |
| 错误 | 红色边框 + 错误提示 | 验证失败 |

### 步进交互

| 操作 | 行为 | 步长 |
|------|------|------|
| 点击增加 | 数值 + step | 默认1 |
| 点击减少 | 数值 - step | 默认1 |
| 长按加速 | 步进加速 | 200ms后加速 |
| 键盘↑ | 数值 + step | - |
| 键盘↓ | 数值 - step | - |

### 键盘支持

| 按键 | 行为 |
|------|------|
| ↑ | 数值增加一个步长 |
| ↓ | 数值减少一个步长 |
| Page Up | 数值增加10倍步长 |
| Page Down | 数值减少10倍步长 |
| Home | 跳转到最小值 |
| End | 跳转到最大值 |

## CSS变量格式

```css
/* 数字输入框组件变量 */
:root {
  /* 数字输入框基础 */
  --input-number-height-sm: 24px;
  --input-number-height-default: 32px;
  --input-number-height-lg: 40px;
  --input-number-width-sm: 80px;
  --input-number-width-default: 120px;
  --input-number-width-lg: 160px;
  --input-number-padding: 0 12px;
  --input-number-border-radius: 4px;
  --input-number-font-size: 14px;

  /* 边框颜色 */
  --input-number-border-color: var(--color-blue-gray-default);
  --input-number-hover-border-color: var(--color-blue-gray-d20);
  --input-number-focus-border-color: var(--color-poseidon-blue-default);
  --input-number-disabled-bg: var(--color-gray-l30);

  /* 步进按钮 */
  --input-number-control-width: 24px;
  --input-number-control-bg: var(--color-gray-l40);
  --input-number-control-icon-size: 14px;
  --input-number-control-hover-bg: var(--color-poseidon-blue-l20);
  --input-number-control-disabled-bg: var(--color-gray-l30);
}
```

## 变体类型

### 基础数字输入

```
┌─────────────┐
│     10      │
└─────────────┘
```

### 带步进按钮

```
┌───────────────────┐
│ - │      10   │ + │
└───────────────────┘
```

### 带前后缀

```
┌───────────────────┐
│ $ │      10.00  │   │
└───────────────────┘

┌───────────────────┐
│   │      100   │ % │
└───────────────────┘
```

### 不同尺寸

```
Small   ┌────┐
        │ 10 │
        └────┘

Default ┌────────┐
        │   10   │
        └────────┘

Large   ┌────────────┐
        │     10     │
        └────────────┘
```

## 功能配置

### 参数配置

| 参数 | 取值 | 说明 |
|------|------|------|
| 步长 | number | 每次加减的值 |
| 最小值 | number | 允许的最小值 |
| 最大值 | number | 允许的最大值 |
| 精度 | number | 小数位数 |
|  Controls | boolean | 是否显示步进按钮 |
| 前缀 | string | 前缀文本 |
| 后缀 | string | 后缀文本 |
| 格式化 | function | 自定义格式化 |

### 精度控制

| 场景 | 精度 | 示例 |
|------|------|------|
| 整数 | 0 | 10 |
| 金额(元) | 2 | 10.00 |
| 百分比 | 0-2 | 50% / 50.5% |
| 价格 | 2 | ¥100.00 |

### 边界处理

| 模式 | 行为 |
|------|------|
| 截断 | 超过边界后截断 |
| 环绕 | 超过边界后回到另一端 |
| 约束 | 阻止超过边界 |

## 使用规范

### 使用原则

1. **合理步长**：根据业务场景设置步长
2. **明确范围**：设置合理的最小最大值
3. **格式统一**：小数位数保持一致
4. **单位标注**：配合单位后缀显示
5. **边界处理**：明确达到边界的反馈

### 使用示例

| 场景 | 步长 | 最小值 | 最大值 | 精度 |
|------|------|--------|--------|------|
| 数量 | 1 | 1 | 999 | 0 |
| 价格 | 0.01 | 0.01 | - | 2 |
| 百分比 | 1 | 0 | 100 | 0 |
| 时间(秒) | 1 | 0 | 3600 | 0 |

## 最佳实践

### 正确示例

- 金额输入配合¥前缀
- 百分比输入配合%后缀
- 折扣设置使用0.01步长
- 库存数量设置最小值为1

### 避免事项

- 不要缺少单位和范围提示
- 不要步长设置不符合业务
- 不要超过边界无反馈
- 不要精度设置混乱

## 关联文档

- [输入框组件](./输入框-Input.md)
- [按钮组件](./按钮-Button.md)
- [选择器组件](./选择器-Select.md)
