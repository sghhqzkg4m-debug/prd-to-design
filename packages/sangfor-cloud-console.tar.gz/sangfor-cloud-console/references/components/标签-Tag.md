---
name: "云BG设计规范-基础组件-标签（tag）"
description: "提供标签组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现标签（Tag）组件时调用。"
step:
  1. 需求解析：理解用户需要创建的标签类型（矩形标签、圆角标签、描边标签、填充标签）及其具体的业务语义（如：成功、告警、错误等）。
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码。
---

# 标签

## 概述

### 功能说明

本技能提供标签（Tag）组件的完整设计规范。标签用于标记事物的属性和维度，帮助用户快速识别、分类和导航相关信息。

### 使用场景

适用于以下情况：
- **属性展示**：用于展示事物的多维度属性（如：文章标签、商品属性等）。
- **分类与筛选**：用于对数据或内容进行分类，在特定场景下可作为筛选器进行点击交互。
- **动态控制**：包含固定展示的标签和可交互（可移除/添加）的标签。可移除标签在表单或筛选条件中表现形态一致（带有"X"关闭按钮）。

### 标签类型

#### 矩形标签（默认）
- **特点**：最基础的标签样式，采用带有轻量级背景色的矩形（带基础圆角），可分为填充和边框类。
- **适用场景**：默认展示标签属性，通常仅用于查看，不支持复杂的交互。

#### 圆角标签
- **特点**：标签左右两端呈现半圆（胶囊状）样式，视觉上更显柔和。可分为填充和边框类。
- **适用场景**：满足特定的排版诉求，或用于区分不同层级的标签分类。

## 设计规范

### 颜色规范

#### 颜色引用规范

**颜色引用方式：**
生成代码时，将自然语言颜色转换为CSS变量格式：`{颜色名}.{色阶}` → `var(--color-{颜色名}-{色阶})`

#### 颜色token使用规范

**禁止硬编码规则：**
生成代码时，文档中定义的所有设计Token（如颜色、间距、圆角、字体等）**必须**使用CSS变量引用，**禁止**直接使用硬编码值。

**正确示例：**
```css
color: var(--color-gray-d50);
border: 1px solid var(--color-blue-gray-l30);
```

**错误示例：**
```css
color: #404655;
border: 1px solid #EBEDF0;
```

#### 颜色样式详情

| 标签颜色类型 | 标签语义类型 | 文字/图标的颜色 | 关闭按钮-默认的颜色 | 关闭按钮-悬浮的颜色 | 关闭按钮-禁用的颜色 | 边框颜色 | 背景色 |
|---------|---------|-----------|--------------|--------------|--------------|------|--------|
| **边框类** | 主色/默认 | `poseidon-blue.default` | 60% | 100% | 24% | `poseidon-blue.l50` | `poseidon-blue.l60` |
| **边框类** | 成功 | `belarus-green.d10` | 60% | 100% | 24% | `belarus-green.l50` | `belarus-green.l60` |
| **边框类** | 普通告警 | `golden-yellow.d10` | 60% | 100% | 24% | `golden-yellow.l50` | `golden-yellow.l60` |
| **边框类** | 重要告警 | `classical-red.d30` | 60% | 100% | 24% | `classical-red.l50` | `classical-red.l60` |
| **边框类** | 轻微告警 | `golden-yellow.d40` | 60% | 100% | 24% | `golden-yellow.l60` | `golden-yellow.l70` |
| **边框类** | 中性 | `graphite-black.l50` | 60% | 100% | 24% | `blue-gray.l10` | `blue-gray.l60` |
| **边框类** | 次要/失效 | `blue-gray.d50` | 60% | 100% | 24% | `blue-gray.l20` | `blue-gray.l80` |
| **填充类** | 主色/默认 | `gray.l60` | 60% | 100% | 24% | - | `poseidon-blue.default` |
| **填充类** | 次要/失效 | `gray.l60` | 60% | 100% | 24% | - | `blue-gray.d10` |
| **填充类** | 成功 | `gray.l60` | 60% | 100% | 24% | - | `belarus-green.default` |
| **填充类** | 普通告警 | `gray.l60` | 60% | 100% | 24% | - | `golden-yellow.default` |
| **填充类** | 重要告警 | `gray.l60` | 60% | 100% | 24% | - | `classical-red.d30` |
| **填充类** | 轻微告警 | `lemon-yellow.d50` | 60% | 100% | 24% | - | `lemon-yellow.l10` |
| **填充类** | 中性 | `gray.l60` | 60% | 100% | 24% | - | `graphite-black.l60` |

*(注：关闭按钮-默认/悬浮/禁用是在文字/图标颜色基础上增加透明度。)*

### 尺寸规范

*统一说明：*
- *宽度：自适应（auto）*
- *高度：统一 18px*
- *字体大小：12px*
- *矩形圆角：2px*
- *圆角标签圆角：20px（胶囊型）*
- *图标尺寸：12px*
- *关闭按钮尺寸：8px*
- *带图标的标签：左内边距 4px*
- *不带图标的标签：左内边距 8px*

### 图标规范

#### 标签使用图标的场景

| 标签类型 | 形态 | 图标 | 关闭按钮 | 适用场景 |
|---------|------|-----|----------|----------|
| **矩形标签** | 不带图标 | 不带关闭 | 默认展示 |
| **矩形标签** | 带图标 | 不带关闭 | 状态展示 |
| **矩形标签** | 不带图标 | 带关闭 | 可移除筛选 |
| **矩形标签** | 带图标 | 带关闭 | 可移除状态 |
| **圆角标签** | 不带图标 | 不带关闭 | 胶囊形态 |
| **圆角标签** | 带图标 | 不带关闭 | 状态胶囊 |
| **圆角标签** | 不带图标 | 带关闭 | 可移除胶囊 |
| **圆角标签** | 带图标 | 带关闭 | 可移除状态胶囊 |

#### 关闭按钮交互

- **图标间距**：关闭图标与左侧文字的间距为 4px。
- **默认态**：图标颜色为文字/图标颜色的 60% 透明度。
- **悬浮态（Hover）**：鼠标悬停在关闭图标上时，透明度提升至 100%，以提示可点击。
- **禁用态**：图标颜色为文字/图标颜色的 24% 透明度。

## CSS示例

#### 基础样式

**不带图标的标签**
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 2px;
    padding: 0 8px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
```

**带图标的标签**
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 2px;
    padding: 0 8px 0 4px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
```

#### 边框类标签

**边框类-主色/默认**
```css
.element.style {
    border: 1px solid var(--color-poseidon-blue-l50);
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}
```

**边框类-成功**
```css
.element.style {
    border: 1px solid var(--color-belarus-green-l50);
    background-color: var(--color-belarus-green-l60);
    color: var(--color-belarus-green-d10);
}
```

**边框类-普通告警**
```css
.element.style {
    border: 1px solid var(--color-golden-yellow-l50);
    background-color: var(--color-golden-yellow-l60);
    color: var(--color-golden-yellow-d10);
}
```

**边框类-重要告警**
```css
.element.style {
    border: 1px solid var(--color-classical-red-l50);
    background-color: var(--color-classical-red-l60);
    color: var(--color-classical-red-d30);
}
```

**边框类-轻微告警**
```css
.element.style {
    border: 1px solid var(--color-golden-yellow-l60);
    background-color: var(--color-golden-yellow-l70);
    color: var(--color-golden-yellow-d40);
}
```

**边框类-中性**
```css
.element.style {
    border: 1px solid var(--color-blue-gray-l10);
    background-color: var(--color-blue-gray-l60);
    color: var(--color-graphite-black-l50);
}
```

**边框类-次要/失效**
```css
.element.style {
    border: 1px solid var(--color-blue-gray-l20);
    background-color: var(--color-blue-gray-l80);
    color: var(--color-blue-gray-d50);
}

.element.style .icon {
    width: 8px;
    height: 8px;
    color: var(--color-blue-gray-d50);
    opacity: 0.6;
}

.element.style .icon:hover {
    opacity: 1;
}
```

#### 填充类标签

**填充类-主色/默认**
```css
.element.style {
    border: none;
    background-color: var(--color-poseidon-blue-default);
    color: var(--color-gray-l60);
}
```

**填充类-次要/失效**
```css
.element.style {
    border: none;
    background-color: var(--color-blue-gray-d10);
    color: var(--color-gray-l60);
}

.element.style .icon {
    width: 8px;
    height: 8px;
    color: var(--color-gray-l60);
    opacity: 0.6;
}

.element.style .icon:hover {
    opacity: 1;
}
```

**填充类-成功**
```css
.element.style {
    border: none;
    background-color: var(--color-belarus-green-default);
    color: var(--color-gray-l60);
}
```

**填充类-普通告警**
```css
.element.style {
    border: none;
    background-color: var(--color-golden-yellow-default);
    color: var(--color-gray-l60);
}
```

**填充类-重要告警**
```css
.element.style {
    border: none;
    background-color: var(--color-classical-red-d30);
    color: var(--color-gray-l60);
}
```

**填充类-轻微告警**
```css
.element.style {
    border: none;
    background-color: var(--color-lemon-yellow-l10);
    color: var(--color-lemon-yellow-d50);
}
```

**填充类-中性**
```css
.element.style {
    border: none;
    background-color: var(--color-graphite-black-l60);
    color: var(--color-gray-l60);
}
```

#### 带关闭按钮的标签

**边框类-可移除筛选**（不带图标，带关闭按钮）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 2px;
    padding: 0 8px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: 1px solid var(--color-poseidon-blue-l50);
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}

.element.style .icon {
    width: 8px;
    height: 8px;
    color: var(--color-poseidon-blue-default);
    opacity: 0.6;
}

.element.style .icon:hover {
    opacity: 1;
}
```

**填充类-可移除状态**（带图标，带关闭按钮）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 2px;
    padding: 0 8px 0 4px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: none;
    background-color: var(--color-belarus-green-default);
    color: var(--color-gray-l60);
}

.element.style .icon {
    width: 8px;
    height: 8px;
    color: var(--color-gray-l60);
    opacity: 0.6;
}

.element.style .icon:hover {
    opacity: 1;
}
```

#### 圆角标签（胶囊形态）

**圆角边框类-胶囊形态**（不带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: 1px solid var(--color-poseidon-blue-l50);
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}
```

**圆角边框类-胶囊形态**（带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 4px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: 1px solid var(--color-poseidon-blue-l50);
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}
```

**圆角填充类-胶囊形态**（不带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: none;
    background-color: var(--color-poseidon-blue-default);
    color: var(--color-gray-l60);
}
```

**圆角填充类-胶囊形态**（带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 4px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: none;
    background-color: var(--color-poseidon-blue-default);
    color: var(--color-gray-l60);
}
```

**圆角边框类-次要/失效胶囊形态**（不带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: 1px solid var(--color-blue-gray-l20);
    background-color: var(--color-blue-gray-l80);
    color: var(--color-blue-gray-d50);
}
```

**圆角填充类-次要/失效胶囊形态**（不带图标）
```css
.element.style {
    height: 18px;
    font-size: 12px;
    border-radius: 20px;
    padding: 0 12px 0 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    border: none;
    background-color: var(--color-blue-gray-d10);
    color: var(--color-gray-l60);
}
```

## 常见问题

### 标签内的文字和关闭图标垂直不居中
**解决方案**: 确保标签容器使用了 Flex 布局（`display: inline-flex; align-items: center;`），并且关闭图标的 `line-height` 和 `font-size` 调整准确。

### 描边标签在某些背景下看不清边界
**解决方案**: 描边标签（Outline）适用于白色或极浅的背景色。如果在深色或复杂背景上使用，建议切换为带有不透明背景色的默认标签或实色标签。

### 多个标签水平排列时间距如何设置？
**解决方案**: 当多个标签水平排列时，标签之间的标准水平间距（gap）应为 `8px`。上下换行时间距也应为 `8px`。

### 标签内文本过长如何处理？
**解决方案**: 当标签内部文本过长（超出容器最大宽度）时，必须使用省略号 `...` 截断，并支持通过 Tooltip 悬浮展示完整内容。

### 空间有限时如何展示多个标签？
**解决方案**: 在空间有限的容器（如表格单元格）中展示多个标签时，建议最多展示 2-3 个，超出的标签合并为 `+N` 样式（如 `+3`），鼠标悬停时展示全部标签列表。

### 生成边框类标签时容易遗漏属性
**提醒**: 生成边框类标签时，必须从颜色规范表中同时取出「边框颜色」和「背景色」两个值，缺一不可。

### 自行推断标签颜色或混合样式类型
**解决方案**: 颜色值**必须**从本文档「颜色样式详情」表格中选取，禁止自行推断或使用其他色值；边框类和填充类是不同的类型，禁止混合不同类型的样式。

**错误示例：**
```html
<!-- ❌ 错误：自行推断标签颜色 -->
<span class="tag" style="background: #e8e8e8;">标签</span>

<!-- ✅ 正确：严格遵循标签规范 -->
<span class="tag-outline">边框类标签</span>
```

```css
/* ❌ 错误：边框类标签缺少border属性 */
.tag-outline {
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}

/* ✅ 正确：边框类标签必须同时设置border和background */
.tag-outline {
    border: 1px solid var(--color-poseidon-blue-l50);
    background-color: var(--color-poseidon-blue-l60);
    color: var(--color-poseidon-blue-default);
}

/* ❌ 错误：混合边框类和填充类样式 */
.tag-mixed {
    border: 1px solid var(--color-poseidon-blue-l50);  /* 边框类 */
    background: var(--color-poseidon-blue-default);       /* 填充类 */
}
```

## 验证清单

生成标签样式后，逐项核对：
- [ ] 颜色是否来自文档规定的CSS变量
- [ ] 边框类标签是否同时包含 `border` 和 `background` 属性
- [ ] 尺寸是否符合尺寸规范表（高度18px、圆角2px）
- [ ] 类型名称是否与文档一致（边框类/填充类）
- [ ] 所有图标是否使用SKILL自带的SVG Symbol图标系统，引用格式为 `#vtv-icon-{图标名}`（禁止使用iconfont或 `--vtv-icon-` 错误前缀）

## 关联文档

- [颜色系统](../../design-system.md)
- [图标系统](../../design-system.md)
