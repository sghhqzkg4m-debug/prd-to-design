---
name: "云BG设计规范-基础组件-统计数据（Statistic）"
description: "提供统计数据组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现统计数据组件时调用。"
step:
  1. 需求解析：理解用户需要的统计类型（基础统计/趋势统计/对比统计）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 统计数据 Statistic

## 概述

统计数据用于突出展示关键业务指标数值，配合趋势指示器和辅助描述。

- **来源**：深信服云BG设计部
- **类型**：数据展示组件
- **适用场景**：仪表盘、数据看板、数据卡片、报表中心

## 使用场景

统计数据组件适用于以下情况：

- **仪表盘概览**：展示关键 KPI 指标
- **数据看板**：多维度数据对比展示
- **业务报表**：收入、用户、订单等核心指标
- **趋势分析**：同比/环比数据展示

## 设计规范

### 尺寸规范

#### 卡片尺寸

| 类型 | 卡片宽度 | 卡片高度 | 适用场景 |
|------|----------|----------|----------|
| 标准 | 240px | 120px | 网格布局 |
| 紧凑 | 200px | 100px | 高密度布局 |
| 宽松 | 280px | 140px | 强调展示 |

#### 数值字号

| 尺寸 | 主数值 | 辅助数值 | 标签文字 |
|------|--------|----------|----------|
| 小 | 24px | 14px | 12px |
| 默认 | 32px | 16px | 14px |
| 大 | 40px | 18px | 16px |

### 组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Statistic | 统计主容器 | 必需 |
| StatisticValue | 数值区域 | 必需 |
| StatisticLabel | 标签区域 | 必需 |
| StatisticTrend | 趋势指示 | 可选 |
| StatisticPrefix | 前缀 | 可选 |
| StatisticSuffix | 后缀 | 可选 |
| StatisticComparison | 对比信息 | 可选 |

### 颜色规范

| 元素 | 颜色 | Token |
|------|------|-------|
| 主数值 | 石墨黑 | Gray.d50 |
| 标签文字 | 中性灰 | Gray.d30 |
| 上升趋势 | 成功绿 | belarusGreen.default |
| 下降趋势 | 危险红 | classicalRed.default |
| 持平趋势 | 中性灰 | Gray.d30 |
| 边框 | Gray.l20 | `var(--color-gray-l20)` |
| 背景 | 白色 | #FFFFFF |

### 趋势指示规范

| 趋势类型 | 图标 | 颜色 | 含义 |
|----------|------|------|------|
| 上升 | ↑ | belarusGreen | 同比增长 |
| 下降 | ↓ | classicalRed | 同比下降 |
| 持平 | → | Gray.d30 | 无变化 |
| 上升(成本类) | ↑ | classicalRed | 成本上升(负面) |
| 下降(成本类) | ↓ | belarusGreen | 成本下降(正面) |

### 状态规范

| 状态 | 样式描述 |
|------|----------|
| 默认 | 白色背景，浅灰边框 |
| 悬浮 | 轻微阴影加深，border-color 变化 |
| 加载中 | 数值区域显示骨架屏 |
| 空数据 | 显示 "--" 占位 |

## 代码示例

### 基础统计

```html
<div class="statistic">
  <div class="statistic-label">总用户数</div>
  <div class="statistic-value">
    <span class="statistic-prefix">¥</span>
    <span class="statistic-number">128,456</span>
    <span class="statistic-suffix">+12.5%</span>
  </div>
  <div class="statistic-trend">
    <span class="trend-icon trend-up">↑</span>
    <span class="trend-text">较上月增长 12.5%</span>
  </div>
</div>
```

### 样式代码

```css
/* 统计卡片 */
.statistic {
  display: flex;
  flex-direction: column;
  padding: 16px;
  background: #FFFFFF;
  border: 1px solid var(--color-gray-l20);
  border-radius: var(--border-radius-md);
  min-width: 200px;
  transition: box-shadow 0.2s, border-color 0.2s;
}

.statistic:hover {
  box-shadow: var(--shadow-sm);
  border-color: var(--color-blue-gray-d20);
}

/* 标签 */
.statistic-label {
  font-size: 14px;
  line-height: 20px;
  color: var(--color-gray-d30);
  margin-bottom: 8px;
}

/* 数值区域 */
.statistic-value {
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.statistic-prefix {
  font-size: 16px;
  color: var(--color-gray-d50);
}

.statistic-number {
  font-size: 32px;
  font-weight: 600;
  font-family: 'DIN Alternate', -apple-system, sans-serif;
  color: var(--color-gray-d50);
  line-height: 1.2;
}

.statistic-suffix {
  font-size: 14px;
  color: var(--color-belarus-green-default);
}

/* 趋势指示 */
.statistic-trend {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 8px;
  font-size: 12px;
}

.trend-icon {
  font-size: 12px;
}

.trend-up {
  color: var(--color-belarus-green-default);
}

.trend-down {
  color: var(--color-classical-red-default);
}

.trend-equal {
  color: var(--color-gray-d30);
}

.trend-text {
  color: var(--color-gray-d30);
}
```

## 最佳实践

### DO

- 使用户一眼能看出核心数据
- 配合趋势指示器展示变化
- 数值使用千位分隔符
- 合理使用前缀/后缀

### DON'T

- 不要展示过多小数位
- 避免数据过于密集
- 不要缺少对比基准
- 不要忽略空数据状态
