---
name: "云BG设计规范-基础组件-输入框（input）"
description: "提供输入框组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/skill.md中定义的设计规范。当用户需要设计或实现输入框组件时调用。"
step:
  1. 需求解析：理解用户需要创建的输入框类型（基础输入框、带图标输入框、带提示输入框、多行输入框）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/skill.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---


## Purpose / 目标

输出并维护标准化的输入框（Input）组件规范，确保组件在不同场景下的一致性和可用性。交付内容包含：

- **结构**：Label + 输入框容器 +（可选）前缀/后缀/单位/图标 +（可选）错误提示
- **尺寸**：支持 32px（标准）和 24px（紧凑）两种高度
- **类型**：常规输入框、带单位输入框、前后缀输入框、密码输入框
- **状态**：Default（默认）、Hover（悬停）、Focus（聚焦）、Disabled（禁用）、Error（错误）

样式效果以本文档中定义的 Source Tokens 为准，包含完整的样式规范。

---

## When to Use / 触发场景

输入框组件适用于以下场景：

- **基础输入**：用户需要输入简短的单行文本或数字，如名称、编号等。
- **密码输入**：涉及安全性信息输入，需支持明文/密文切换功能。
- **固定组合**：适配带单位（如“天”、“元”）或特定前后缀（如域名、协议头）的输入场景。
- **表单域**：作为表单的最基础组成单元，用于收集用户输入信息。

---

## Source Tokens / 样式来源要点

Source Tokens 定义了输入框组件的完整样式规范，包括结构、尺寸、颜色、交互状态等关键信息。

### 1. 基础结构与布局

#### 组件层级结构
- **单个组件容器**：宽度 304px，高度 32px（标准尺寸）或 24px（紧凑尺寸），采用绝对定位
- **标签容器**：采用左对齐的弹性盒布局，标签与输入框间距 4px

#### 核心元素样式
- **标签（Label）**：固定宽度 38px，高度与输入框一致（32px 或 24px），文字颜色为 `Gray.D50`，采用 PingFang SC 字体，字号 12px，文字不换行
- **输入框主容器**：宽度 262px，高度与输入框一致（32px 或 24px），圆角 2px，采用弹性盒布局，元素垂直居中对齐
- **输入文本区域**：宽度根据输入框类型自适应（常规输入框 238px，前后缀输入框 246px），高度 20px，文字采用 PingFang SC 字体，字号 12px，行高 20px，超长文本使用省略号显示

#### 布局规则
- 所有元素使用 flex 布局实现对齐
- 输入框内部元素垂直居中
- 标签与输入框左对齐，间距 4px
- 错误提示框绝对定位在输入框下方 4px 处

### 2. 尺寸规范

#### 32px 尺寸（标准）
- 容器高度：32px
- 内边距：`padding: 6px 12px`（常规/密码类型）或 `padding: 5px 8px 5px 12px`（前后缀类型）
- 文字与边框左右间距：12px

#### 24px 尺寸（紧凑）
- 容器高度：24px
- 内边距：`padding: 2px 8px`
- 文字与边框左右间距：8px

#### 字体规范
- 字体族：PingFang SC
- 字号：12px
- 行高：20px
- 字重：400

### 3. 交互状态样式

| 状态 | 背景色 | 边框色 | 阴影 | 文字颜色 |
|------|--------|--------|------|----------|
| **Default（常规/前后缀）** | `gray.l60` | `blue-gray.default` | - | 占位符 `gray.default`，已有值 `gray.d60` |
| **Default（密码）** | `gray.l60` | `blue-gray.d20` | - | 占位符 `gray.default`，已有值 `gray.d60` |
| **Hover** | `gray.l60` | `blue-gray.d20` | - | 同 Default |
| **Focus** | `gray.l60` | `poseidon-blue.default` | - | 同 Default |
| **Click** | `gray.l60` | `poseidon-blue.default` | - | 同 Default |
| **Disabled** | `gray.l20` | `blue-gray.default` | - | 占位符 `gray.d10`，已有值 `gray.d40` |
| **Error** | `gray.l60` | `classical-red.default` | - | 同 Default |

### 4. 输入框类型规范

#### 常规输入框
- 基础结构：Label + 输入框容器 + 输入文本区域
- 内边距：32px 尺寸 `padding: 6px 12px`，24px 尺寸 `padding: 2px 8px`

#### 带单位输入框
- 结构：Label + 输入框容器 + 输入文本区域 + 单位
- 单位位置：输入框外部右侧
- 单位与输入框间距：8px

#### 前后缀输入框
- 结构：Label + 输入框容器 +（前缀 + 分隔线）+ 输入文本区域 +（分隔线 + 后缀）
- 前后缀与输入区分隔：使用 `blue-gray.l10` 分隔线
- 前缀文字左侧间距：12px
- 前缀分割线与下拉图标间隔：0px
- 前缀分割线与输入文案间距：32px 尺寸为 12px，24px 尺寸为 8px
- 状态样式：与常规输入框保持一致，支持 Default、Hover、Focus、Click、Disabled、Error 所有状态

##### 前后缀下拉功能
- **支持范围**：前缀和后缀均支持下拉功能
- **下拉图标**：使用 `vtv-icon-comp-angle-down` 图标，位于前后缀文本右侧
- **图标样式**：图标大小 16px x 16px，与前后缀文本间距 0px
- **点击效果**：触发输入框容器的点击状态（status-click）样式
- **下拉菜单样式**：
  - 背景色：`Gray.L60`
  - 边框：1px solid `PoseidonBlue.L20`
  - 阴影：2px 4px 16px 0px shadow.stroke
  - 圆角：2px
  - 内边距：3px 13px 3px 12px
  - 与输入框间距：3px
- **状态同步**：下拉菜单显示时输入框保持点击状态，关闭时移除点击状态

#### 密码输入框
- 结构：Label + 输入框容器 + 输入文本区域 + 密码切换图标
- 默认状态：显示 `vtv-icon-hide-password` 图标，密文显示输入内容
- 切换效果：点击图标切换为 `vtv-icon-show-group`，明文显示输入内容

### 5. 错误提示样式

#### 错误提示容器
- 定位：position: absolute, top: 29px（32px 尺寸）/21px（24px 尺寸）, left: 42px
- 尺寸：width: 243px, height: 30px
- 布局：display: flex, flex-direction: column, justify-content: start, align-items: start, column-gap: -4px

#### 错误提示内容
- **箭头**：宽度 30px，高度 9px，不可压缩
- **提示框**：宽度 243px，高度 25px，圆角 2px，内边距 4px 上下、8px 左右，背景色为 `ClassicalRed.default`，不可压缩
- **提示文字**：宽度 227px，高度 17px，文字颜色为 `Gray.L60`，采用 PingFang SC 字体，字号 12px，行高 17px，字重 400，文字不换行，垂直居中显示

---

## Component Anatomy / 组件拆解

输入框组件采用模块化结构设计，各部分协同工作以实现完整功能。

### 核心结构组成

| 组件部分 | 说明 |
|----------|------|
| **Input Field Container** | 整体容器，采用 **左右结构** (Flex Row) 布局，包含标签和输入区。 |
| **Label (可选)** | 左侧标签，固定宽度（通常 38px），垂直居中，用于描述输入内容。 |
| **Input Wrapper** | 右侧输入框主容器，承载背景、边框及所有内部元素，是样式和状态的主要载体。 |
| **Prefix/Suffix (可选)** | 用于增强语义的图标或文字，可位于输入框内部两侧，支持下拉功能。 |
| **Input Element** | 真实的文本输入区域，负责接收用户输入。 |
| **Error Tips (可选)** | 展示在输入框下方的校验失败反馈信息，采用浮层形式。

---

## Component Resources / 组件资源

输入框组件使用以下资源文件和功能模块：

| 资源类型 | 资源名称 | 路径/说明 |
|----------|----------|-----------|
| **图标资源** | 下拉图标 | `vtv-icon-comp-angle-down` - 用于前后缀的下拉选择功能按钮 |
| **图标资源** | 密码显示图标 | `vtv-icon-show-group` - 用于密码输入框的明文显示状态 |
| **图标资源** | 密码隐藏图标 | `vtv-icon-hide-password` - 用于密码输入框的密文显示状态 |
| **功能模块** | 下拉菜单 | 点击下拉图标后显示的选项列表容器，包含样式和交互逻辑 |

---

## Input Contract / 输入约定

在生成或更新输入框规范前，需明确以下关键输入参数：

| 参数名称 | 取值范围 | 说明 |
|----------|----------|------|
| **Type / 类型** | regular / unit / affix / password | 指定输入框类型，默认为 regular（常规输入框） |
| **Size / 尺寸** | 32px / 24px | 指定输入框高度，默认为 32px（标准尺寸） |
| **Status / 状态** | default / hover / focus / click / disabled / error | 指定输入框当前状态，默认为 default（默认状态） |
| **Label** | string | 输入框左侧标签文本，可选配置 |
| **Placeholder** | string | 输入框占位文本，用于提示用户输入内容 |
| **Unit / Affix** | string | 单位或前后缀文本，仅在对应类型（unit/affix）时需要 |

---

## Quality Rules / 质量规则

为确保输入框组件的质量和一致性，需严格遵循以下规则：

### 1. 视觉对齐规则
- **垂直居中**：所有内部元素（文字、图标、分隔线）必须在容器内垂直居中。
- **标签对齐**：Label 与输入框之间的间距固定为 4px，保持左对齐。

### 2. 状态交互规则
- **状态一致性**：严禁在 Disabled 状态下出现 Hover/Focus 视觉反馈。
- **错误反馈**：Error 状态必须同时包含红色边框和对应的错误提示信息。错误提示采用浮层形式，不占用输入框容器的高度，定位在输入框下方 4px 处。输入框聚焦时显示完整错误状态（红色边框 + 淡红色阴影 + 浮层错误提示），失焦后恢复正常状态。
- **事件隔离**：点击前后缀区域的下拉图标时，应触发输入框容器的点击状态（status-click）样式。

### 3. 间距规范规则
- **文字与边框间距**：严格遵守 `12px` (32px 尺寸) 或 `8px` (24px 尺寸) 的左右间距规范。
- **前后缀间距**：前缀的分割线与下拉图标间隔 0px；32px 高的前缀分割线与输入文案的间距是 12px，24px 高的前缀分割线与输入文案的间距是 8px。

---

## 推荐实现 (React)

以下是基于 React 框架的输入框组件推荐实现方案，支持 TypeScript 类型定义，确保组件的可维护性和扩展性。

### 1. 组件结构设计

#### 核心结构

输入框组件采用 React 函数式组件实现，支持 TypeScript 类型定义，主要包含以下部分：

- **组件声明**：定义为函数式组件，接收丰富的 props 参数
- **默认属性**：为常用属性设置合理默认值，如默认类型为常规输入框(regular)，默认尺寸为32px，默认状态为default
- **状态管理**：
  - 使用 useState 钩子管理密码可见性状态
  - 使用 useState 钩子管理下拉菜单可见性状态
- **属性传递**：支持通过 rest 运算符接收并传递额外属性

组件接收的主要属性包括：类型(type)、尺寸(size)、状态(status)、标签(label)、占位文本(placeholder)、当前值(value)、单位(unit)、前缀(prefix)、后缀(suffix)和错误提示信息(errorMsg)。

#### Props 定义
| Prop 名称 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| type | string | 'regular' | 输入框类型：regular/unit/affix/password |
| size | string | '32px' | 输入框尺寸：32px/24px |
| status | string | 'default' | 输入框状态：default/hover/focus/click/disabled/error |
| label | string | - | 输入框左侧标签文本 |
| placeholder | string | - | 输入框占位文本 |
| value | string | - | 输入框当前值 |
| unit | string | - | 输入框单位（仅 type='unit' 时有效） |
| prefix | string | - | 输入框前缀（仅 type='affix' 时有效） |
| suffix | string | - | 输入框后缀（仅 type='affix' 时有效） |
| errorMsg | string | - | 错误提示信息（仅 status='error' 时显示） |

### 2. 核心功能实现

#### 类型支持
- **常规输入框**：基础文本输入功能
- **带单位输入框**：支持在输入框外部右侧显示单位
- **前后缀输入框**：支持在输入框内部两侧显示前缀/后缀，支持下拉功能
- **密码输入框**：支持明文/密文切换功能

#### 尺寸适配
- **32px（标准）**：容器高度 32px，内边距 `padding: 6px 12px`（常规/密码）或 `padding: 5px 8px 5px 12px`（前后缀）
- **24px（紧凑）**：容器高度 24px，内边距 `padding: 2px 8px`

#### 状态管理
支持以下交互状态：
- Default（默认）
- Hover（悬停）
- Focus（聚焦）
- Click（点击）
- Disabled（禁用）
- Error（错误）

### 3. 关键实现要点

#### 布局实现
- 采用 Flex 布局实现 Label 和输入框的左右结构
- 确保所有元素垂直居中对齐
- 严格遵守间距规范：文字与边框的左右间距为 12px（32px 尺寸）或 8px（24px 尺寸）
- Label 与输入框之间的间距固定为 4px

#### 特殊功能实现

##### 前后缀功能
- 前后缀区域使用 `blueGray.l10` 分隔线与输入区分开
- 下拉图标使用 `vtv-icon-comp-angle-down` 图标类
- 下拉菜单实现：
  - 使用 useState 管理下拉菜单的可见性状态
  - 采用绝对定位，相对于输入框容器定位
  - 样式：背景色 `Gray.l60`，边框 `1px solid poseidonBlue.l20`，阴影 `2px 4px 16px 0px shadow.stroke`，圆角 `2px`，内边距 `3px 13px 3px 12px`，与输入框的间距为 `3px`
  - 点击下拉图标时触发输入框容器的点击状态（status-click）样式
  - 实现状态同步：下拉菜单显示时保持输入框的点击状态，关闭时移除点击状态
  - 下拉菜单选项使用 Flex 布局，确保垂直居中对齐

##### 密码功能
- 默认图标为 `vtv-icon-hide-password`，密文显示输入内容
- 点击图标切换为 `vtv-icon-show-group`，明文显示输入内容
- 使用 useState 管理密码可见性状态

##### 错误提示
- 采用浮层形式，使用绝对定位，不占用容器高度，定位在输入框下方 4px 处
- Error 状态下仅显示红色边框，不使用阴影效果
- 实现聚焦/失焦交互：聚焦时显示完整错误状态（红色边框 + 浮层错误提示），失焦后恢复正常状态

### 4. 代码优化建议

#### 性能优化
- 使用 React.memo 优化组件渲染性能
- 合理使用 useCallback 和 useMemo 缓存函数和计算结果

#### 可访问性
- 添加适当的 ARIA 属性，确保屏幕阅读器可访问
- 确保所有交互元素都有明确的焦点状态

#### 样式管理
- 推荐使用 CSS Modules 或 styled-components 进行样式管理
- 提取公共样式变量，确保样式一致性

#### 类型安全
- 使用 TypeScript 严格定义组件 props 和内部状态类型
- 添加必要的类型守卫，确保运行时类型安全
