---
name: "云BG设计规范-基础组件-进度条（Progress）"
description: "提供进度条组件的设计规范、最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现进度条组件时调用。"
step:
  1. 需求解析：理解用户需要创建的进度条类型（线性进度条、环形进度条、步骤进度条）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码

ai_instructions:
  icon_usage_rules:
    - "必须使用本文档指定的图标类名，严禁使用其他图标替代"
    - "图标前缀统一为vtv-icon-"
    - "严禁根据语义自行搜索图标，必须按清单使用"
  forbidden_substitutions:
    - "成功图标：必须使用vtv-icon-check-fill，严禁使用check、success等"
    - "错误图标：必须使用vtv-icon-close-fill，严禁使用error、fail等"
  checklist_before_generate:
    - "确认所有图标类名与图标清单一致"
    - "确认图标前缀为vtv-icon-"
    - "确认没有使用任何通用图标替代组件专用图标"

---

# 进度条 Progress

> ⚠️ **图标使用强制声明**：本组件所有图标必须使用下表指定的图标类名，**严禁**使用`check`、`success`、`error`、`fail`等通用图标替代。

## 图标清单（强制）

| 位置 | 图标类名 | 尺寸 | 颜色 | 严禁使用 |
|------|----------|------|------|----------|
| 成功状态 | `vtv-icon-done` | 16px | `belarus-green.default` | `check`, `success`, `tick` |
| 错误状态 | `vtv-icon-failure-fill` | 16px | `classical-red.default` | `close`, `error`, `fail`, `x` |
| 警告状态 | `vtv-icon-warning-fill` | 16px | `golden-yellow.default` | `warning`, `alert` |
| 信息图标 | `vtv-icon-info` | 16px | `poseidon-blue.default` | `info-fill`, `information` |

## 概述

进度条组件用于展示操作的当前进度，帮助用户了解任务完成状态和预计剩余时间。

- **来源**：深信服云BG设计部
- **类型**：基础反馈组件
- **适用场景**：文件上传/下载、表单提交、批量操作、安装/更新流程等

### 使用场景

| 变体 | 适用场景 | 示例 |
|------|---------|------|
| **线形进度条-表达速度** | 展示操作完成进度、传输速度 | 文件上传/下载、数据同步 |
| **线形进度条-表达使用率** | 展示资源使用比例、容量占用 | CPU使用率、内存占用、存储空间 |
| **环形进度条** | 空间受限或需要居中展示 | 仪表盘、加载状态 |
| **微型进度条** | 紧凑空间或内联展示 | 表格行内、卡片内部 |
| **分段进度条** | 等比均分多段展示，类似微型步骤条 | 批量任务进度、多阶段流程 |
| **多段进度条** | 多个任务并行展示 | 批量操作、多文件上传 |
| **步骤进度条** | 多步骤流程导航 | 表单填写、配置向导 |

### 组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Progress | 进度条主容器 | 必需 |
| ProgressTrack | 进度条轨道（背景） | 必需 |
| ProgressBar | 进度填充条 | 必需 |
| ProgressText | 进度文字显示 | 可选 |
| ProgressStatus | 状态图标/文字 | 可选 |
| ProgressStep | 步骤节点（步骤条） | 步骤条必需 |

## 视觉设计规范

### 颜色规范

#### 基础样式（所有变体共用）

| 元素 | 属性 | Token |
|------|------|-------|
| 轨道背景 | background | `blue-gray.l30` |
| 进度填充（默认） | background | `poseidon-blue.default` |
| 进度填充（成功） | background | `belarus-green.default` |
| 进度填充（错误） | background | `classical-red.default` |
| 进度填充（警告） | background | `orange.default` |
| 进度文字 | color | `gray.d50` |
| 辅助文字 | color | `gray.d40` |

#### 状态颜色

| 状态 | 填充色 | 说明 |
|------|--------|------|
| 进行中 | `poseidon-blue.default` | 默认状态，表示任务进行中 |
| 成功 | `belarus-green.default` | 任务完成 |
| 错误 | `classical-red.default` | 任务失败 |
| 警告 | `golden-yellow.default` | 任务异常或需要关注 |

#### 颜色使用场景（表达使用率）

根据资源使用率的不同范围，使用不同颜色表达严重程度：

| 使用率范围 | 颜色 | Token | 说明 |
|-----------|------|-------|------|
| 0% - 60% | 蓝色 | `poseidon-blue.default` | 正常范围 |
| 60% - 80% | 黄色 | `golden-yellow.default` | 警告范围，需关注 |
| 80% - 100% | 红色 | `classical-red.default` | 危险范围，需处理 |

**使用示例**：
- CPU 使用率 45% → 蓝色
- 内存使用率 75% → 黄色
- 磁盘使用率 92% → 红色

### 尺寸规范

#### 线形进度条尺寸

| 尺寸 | 轨道高度 | 圆角 | 适用场景 |
|------|----------|------|----------|
| 微型 (SM) | 2px | 1px | 表格行内、卡片内部、分段进度条 |
| 默认尺寸 (MD) | 6px | 3px | 常规使用（推荐） |
| 大尺寸 (LG) | 12px | 6px | 需要强调的场景、大卡片 |

**设计原则**：线形进度条采用细线风格，默认 6px 为推荐尺寸，视觉上更轻盈

#### 环形进度条尺寸

| 尺寸 | 直径 | 线宽 | 适用场景 |
|------|------|------|----------|
| 小尺寸 (SM) | 40px | 2px | 紧凑空间、列表内 |
| 默认尺寸 (MD) | 64px | 3px | 常规使用（推荐） |
| 大尺寸 (LG) | 96px | 4px | 仪表盘、强调场景 |

**设计原则**：环形进度条采用细线风格，线宽与直径比例约 1:20，视觉上更精致

#### 步骤进度条尺寸

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 节点直径 | 24px | 步骤节点圆形直径 |
| 节点图标 | 12px | 节点内部图标尺寸 |
| 连线高度 | 2px | 步骤间连接线高度 |
| 节点间距 | 120px | 相邻步骤节点间距 |

#### 多段进度条规范

| 属性 | 值 | 说明 |
|------|-----|------|
| 段间距 | 16px | 相邻进度条之间的垂直间距 |
| 标签宽度 | 120px | 左侧标签区域固定宽度 |
| 值宽度 | 80px | 右侧数值区域固定宽度 |
| 对齐方式 | 左对齐 | 所有标签左对齐 |
| 端点形状 | 圆形 | 进度条两端为圆形端点 |
| 端点尺寸 | 8px | 圆形端点直径 |

**多段进度条结构**：
```
[标签区域] [进度条区域] [数值区域]
   120px       自适应        80px
```

**圆形端点实现**：
- 使用伪元素 `::before` 和 `::after` 创建两端圆形
- 圆形直径 8px，继承进度条填充色
- 端点中心与进度条端点对齐

#### 分段进度条规范（等比均分）

分段进度条是多段进度条的紧凑变体，将进度条等比分为多段，类似步骤式但更微型。

| 属性 | 值 | 说明 |
|------|-----|------|
| 轨道高度 | 2px | 更轻量的细线风格 |
| 节点直径 | 8px | 空心圆节点 |
| 节点描边 | 2px | 空心圆描边宽度 |
| 节点间距 | 0px | 节点与线紧密相连 |
| 节点样式 | 空心圆 | 所有状态均为空心圆描边，仅颜色区分 |

**节点样式定义**：

| 状态 | 样式 | 颜色 |
|------|------|------|
| 待处理 (pending) | 空心圆描边 | `blue-gray.l30` |
| 已完成 (completed) | 空心圆描边 | `poseidon-blue.default` |
| 进行中 (active) | 空心圆描边 | `blue-gray.l30` |

**颜色规则**：
- 分段进度条**仅使用**蓝色和灰蓝色
- 禁止使用绿色（成功）、红色（错误）、黄色（警告）等其他颜色
- 蓝色表示已完成和进行中，灰蓝色表示待处理

**实现示例**：
```css
.progress-segmented {
  display: flex;
  align-items: center;
  gap: 0;
}

.progress-segmented-track {
  height: 2px;
  background: var(--color-blue-gray-l30);
  border-radius: 1px;
}

.progress-segmented-node {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  border: 2px solid var(--color-blue-gray-l30);
  background: transparent;
}

.progress-segmented-node.completed {
  border-color: var(--color-poseidon-blue-default);
}

.progress-segmented-node.active {
  border-color: var(--color-poseidon-blue-default);
  background: transparent;
}

.progress-segmented-node.pending {
  border-color: var(--color-blue-gray-l30);
}
```

### 动画规范

| 属性 | 值 | 说明 |
|------|-----|------|
| 进度动画 | 300ms ease-out | 进度变化时的过渡效果 |
| 缓冲动画 | 1.5s ease-in-out infinite | 不确定进度时的缓冲动画 |
| 成功动画 | 300ms ease-out | 进度完成时的缩放效果 |
| 缓动函数 | cubic-bezier(0.4, 0, 0.2, 1) | 标准缓动 |

## 交互设计规范

### 状态定义

| 状态 | 表现 | 说明 |
|------|------|------|
| 默认状态 | 显示当前进度 | 正常展示进度百分比 |
| 缓冲状态 | 进度条往复移动 | 不确定进度时的加载状态 |
| 成功状态 | 填充色变为绿色，显示成功图标 | 任务完成 |
| 错误状态 | 填充色变为红色，显示错误图标 | 任务失败 |
| 警告状态 | 填充色变为橙色，显示警告图标 | 任务异常 |

### 文字显示规则

| 显示类型 | 格式 | 示例 |
|----------|------|------|
| 百分比 | `{percent}%` | 75% |
| 分数 | `{current}/{total}` | 3/5 |
| 文件大小 | `{current}MB/{total}MB` | 150MB/200MB |
| 时间预估 | 剩余{time} | 剩余2分钟 |

## 可访问性规范

| 属性 | 值 | 说明 |
|------|-----|------|
| `role` | `progressbar` | 进度条角色 |
| `aria-valuenow` | 当前值 | 当前进度值 |
| `aria-valuemin` | 最小值 | 通常为0 |
| `aria-valuemax` | 最大值 | 通常为100 |
| `aria-valuetext` | 文字描述 | 如"75%"或"3/5步" |
| `aria-label` | 进度条描述 | 如"文件上传进度" |

## Ant Design 集成

| 属性 | Ant Design Progress | 本规范对应 |
|------|--------------------|-----------|
| `type` | `line` \| `circle` \| `dashboard` | 线性、环形进度条 |
| `percent` | `number` | 进度百分比 |
| `status` | `success` \| `exception` \| `normal` \| `active` | 进度状态 |
| `showInfo` | `boolean` | 是否显示进度文字 |
| `strokeWidth` | `number` | 进度条线宽 |
| `size` | `small` \| `default` | 进度条尺寸 |

## 参数配置

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| type | `line` \| `circle` \| `steps` | `line` | 进度条类型 |
| percent | `number` | `0` | 当前进度百分比（0-100） |
| status | `normal` \| `success` \| `error` \| `warning` | `normal` | 进度状态 |
| size | `sm` \| `md` \| `lg` | `md` | 进度条尺寸 |
| showInfo | `boolean` | `true` | 是否显示进度信息 |
| format | `(percent) => string` | - | 自定义进度文字格式 |
| steps | `number` | - | 步骤进度条的步骤数 |

## 最佳实践

### 命名规范

- **组件集**：`componentset-progress`
- **变体/示例**：
  - `progress-line` - 线性进度条
  - `progress-circle` - 环形进度条
  - `progress-steps` - 步骤进度条
  - `progress-mini` - 微型进度条

### 使用原则

1. **进度反馈**：长时间操作（>2秒）应提供进度条反馈
2. **精度选择**：根据场景选择合适的进度精度，避免过度精确
3. **状态清晰**：成功、错误状态应明确区分，使用对应颜色
4. **文字辅助**：复杂场景配合文字说明当前状态和预计时间
5. **避免抖动**：进度更新应平滑，避免频繁跳动

## 高约束规则

> **生成器必须严格遵守以下规则，违反将导致样式错误。**

### 引用触发条件

当在其他组件文档或生成代码中，识别到以下关键词时，**必须**引用本进度条文档：
- "进度条"、"progress"
- "上传进度"、"下载进度"
- "加载进度"、"处理进度"
- "步骤条"、"步骤进度"

### 强制遵守要求

| 要求 | 说明 |
|------|------|
| **禁止自定义颜色** | 颜色值**必须**从本文档「颜色规范」表格中选取，禁止自行推断或使用其他色值 |
| **禁止自定义尺寸** | 尺寸**必须**严格遵循本文档「尺寸规范」，包括高度、直径、线宽 |
| **禁止省略轨道** | 进度条必须包含轨道背景，建立视觉基准 |
| **状态颜色强制** | 成功/错误/警告状态必须使用对应的颜色Token |
| **图标来源强制** | 状态图标**必须**使用本文档指定的图标类名 |

### 常见错误

| 错误类型 | 错误示例 | 正确做法 |
|---------|---------|---------|
| 硬编码颜色 | `background: #1770E6` | `background: var(--color-poseidon-blue-default)` |
| 省略轨道 | 无轨道背景 | 必须使用`blue-gray.l30`作为轨道背景 |
| 错误状态色 | 成功使用蓝色 | 成功必须使用`belarus-green.default` |
| 错误图标 | `vtv-icon-check` | 必须使用`vtv-icon-check-fill` |
| 尺寸不规范 | 高度10px | 必须使用4px/8px/12px规范尺寸 |

### 验证清单

生成进度条样式后，逐项核对：
- [ ] 颜色是否来自文档规定的CSS变量
- [ ] 尺寸是否符合尺寸规范表（高度、直径、线宽）
- [ ] 是否包含轨道背景
- [ ] 状态颜色是否正确（成功=绿色，错误=红色，警告=橙色）
- [ ] 状态图标是否使用文档指定的图标类名
- [ ] 是否包含适当的ARIA属性

## 关联文档

- [颜色规范](../../design-system.md)
- [图标系统](../../design-system.md)
- [按钮组件](./按钮-Button.md)
