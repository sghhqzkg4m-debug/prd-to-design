# 表格页模板

表格页用于资源管理、数据查询、日志、任务和报表类场景。

## 基准模板

- `templates/table-page/带侧边导航.html`：标准带侧边导航表格页。
- `templates/table-page/SCP=云主机.html`：复杂资源管理表格页，包含更完整的云主机场景和高级交互。
- `templates/table-page/statistics-table-page.html`：统计表格页，复用概览列表页框架，将列表主体替换为统计表格，适用于资源概览、指标统计、报表汇总等场景。

## 必要结构

- 顶部全局导航。
- 左侧侧边导航。
- 内容区。
- 标题栏或面包屑。
- 工具栏。
- 表格主体。
- 分页器。

## 生成规则

- 优先复用参考 HTML 的壳层、颜色 token、表格 class 和分页 class。
- 表格页变体必须继承最接近的表格页模板框架。左树右表、复杂筛选、资源管理详情入口、批量任务等变体，只在内容区增加树、筛选区、状态区或操作区，不重新搭建顶部导航、侧边导航、内容区滚动容器、工具栏、表格和分页的基础结构。
- 统计表格页必须优先复用 `templates/table-page/statistics-table-page.html`。只替换统计卡、筛选项、表格列和行数据，不重新设计概览卡、工具栏、分页、导航和内容区框架。
- 工具栏左侧放主操作和次操作，右侧放筛选、搜索、刷新、导出等功能。
- 表格列优先展示核心字段，操作列放最右侧。
- 数据状态使用图标 + 文本，不只用颜色表达。
- 数据过多时使用分页，不让页面主体无限增长。

## 模板锁定生成规则

创建表格页时，先复制 `templates/table-page/带侧边导航.html`；云主机、专属资源池、宿主机、存储池、网络、安全组、监控告警等复杂资源管理页面优先复制 `templates/table-page/SCP=云主机.html`。复制后只做业务替换，不重写页面壳层。

禁止重写、重命名或重新发明下列模板结构与基础 CSS：

- 顶部全局导航：`.top-nav`、菜单按钮、数据中心、右侧用户与快捷入口。
- 左侧导航：`.side-nav`、`.side-nav-header`、`.side-nav-logo`、`.side-nav-title`、`.side-nav-content`、`.nav-group`、`.nav-item`、`.sub-menu-wrapper`、`.sub-nav-item`、`.side-nav-footer`、`.collapse-btn`。
- 内容区容器：`.main-area`、`.content-area`、`.content-inner`、`.title-bar`。
- 表格工作区：`.toolbar`、`.toolbar-left`、`.toolbar-right`、`.filter-area`、`.general-area`、`.table-card`、`.table-scroll`、分页器和表格操作按钮。

只允许替换这些业务内容：

- 页面标题、侧边导航内容、当前高亮项和展开项。侧边导航的样式、class、DOM 层级和基础 CSS 必须复用模板；但导航菜单的子系统名称、一级/二级菜单文案、菜单数量、层级归属、当前选中项和图标语义可以按业务页面修改。
- 统计卡片的数量、标题、图标和数值。
- 工具栏按钮文案、筛选项选项、搜索 placeholder、是否显示导入/导出/刷新/视图切换。
- 表格列、列宽、行数据、状态展示、操作按钮文案。
- 与业务数据相关的 mock 数据、筛选、分页、批量选择和 toast 文案。

模板尺寸必须保持：

- `.side-nav` 展开宽度 `224px`，`.side-nav.collapsed` 收起宽度 `52px`。
- `.nav-item` 高 `40px`，`.sub-nav-item` 高 `36px`，二者 `width: 100%`、`margin: 0`、`border-radius: 0`，hover/active 背景横向铺满侧边导航。
- `.content-inner` 使用模板的 `padding: 12px 36px`。
- `.toolbar` 高 `52px`、`padding: 10px 0`；`.toolbar-left`、`.toolbar-right`、`.filter-area`、`.general-area` 的元素间距为 `8px`；`.general-area` 保留 `margin-left: 8px`。
- `.table-card` 继续承载表格和分页，表格内部滚动，不让 `body` 成为滚动容器。

图标必须保留 `vtv-icon-*` 体系。禁止新造 `i-*`、`icon-*` 或语义相近的临时 symbol；新增图标只能从 `assets/iconfont/icon-symbols.html` 拷贝真实 `vtv-icon-*` symbol，或复用模板中已内联的 symbol。

如果模板和组件详细文档发生冲突，表格页以模板为准；组件文档只用于补充表格列、按钮、选择器、搜索框等局部控件细节。
