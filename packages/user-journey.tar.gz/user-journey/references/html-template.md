# 独立用户旅程 HTML 模板

默认模板为 `assets/user-journey-template.html`；生成脚本 `scripts/render-document.py`、组件脚本 `scripts/render-journeys.py` 与模板一起维护。

独立文档保持「业务场景封面 → 核心判断 → 按实际 Case 的完整旅程 → 改进机会汇总 → 待确认与验证」。Case 数量、阶段跨度、角色和动作数量由业务决定；不复制主需求文档的九章。被主 Skill 调用时只返回相同旅程组件与数据，由主文档保留其结构。

`assets/user-journey-template-data.json` 是中性数据结构，不是项目事实。封面、元信息、上下文、动作和体验行全部由数据填充。文本均转义；状态和优先级使用结构化字段，不传任意 HTML。旧的字符串体验字段仍可渲染，优先使用结构化字段。

- thinking：text、status；推断使用标签，不重复前缀。
- pain：text、status、critical；区分材料、待确认、方案假设。
- need：text；用「需要一种方式……，以便……」表达期望结果。
- idea：title、priority、detail、owner；责任缺证据时标待确认。
- evidence：metric、status、detail；无可靠基线不填目标数值。
- opportunities：title、problem、actions、priority、basis；新能力保持候选方案身份。

运行 `python3 scripts/render-document.py document.json output.html`，再运行 `python3 scripts/validate-journey.py output.html`。实际检查桌面、窄屏、横向滚动、各图独立筛选、全屏与退出，以及标签不遮挡卡片。

主 Skill 的 `render-journeys.py` 和模板内旅程 CSS/JS 与本 Skill 同步维护；修改共享连线能力时同时更新主模板和独立模板，保留各自文档框架。

现状旅程与目标旅程使用不同的体验行。数据显式设置 `type: current` 或 `type: target`：现状保留所说／所想、现状断点、用户需求、设计点子、衡量与证据；目标在角色泳道下展示「目标体验（业务改善）」「支持设计（对应现状需求与点子）」「验证指标（口径与验证方式）」三行，不继续显示现状断点或把风险当作目标体验。目标风险、前提和恢复放在对应动作、返回连线或图下交接说明。目标动作需填写 `experience`、`design`、`metrics`；没有可靠基线时不编目标值。目录采用「组织 / 场景 · 现状旅程」或「组织 / 场景 · 目标旅程」。
