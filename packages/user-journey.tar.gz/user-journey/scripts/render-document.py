# -*- coding: utf-8 -*-
"""Build a standalone journey HTML from its local template.
Usage: python3 render-document.py document.json output.html [--template template.html]
Document: title,date,subtitle,intro,meta[{label,text}],overview[{label,text}],
overview_note,scope_note,evidence_note,journeys[],opportunities[],competition_note,
verification[],sources[]. Opportunity: title,problem,actions,priority,basis.
"""
import argparse,json,re,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('journey',Path(__file__).with_name('render-journeys.py'))
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
e=r.e

def build(doc,template):
    sections=[];nav=[]
    def section(id,title,desc,body,short=None):
        number=len(sections)+1
        sections.append(f'<section class="chapter" id="{e(id)}"><div class="chapter-head"><span class="chapter-index">{number:02}</span><div><h2>{e(title)}</h2><p class="chapter-desc">{e(desc)}</p></div></div>{body}</section>')
        nav.append(f'<a href="#{e(id)}"><span>{number:02}</span>{e(short or title)}</a>')
    cards='<div class="summary-strip">'+''.join(f'<div class="summary-item"><div class="summary-label">{e(x["label"])}</div><div class="summary-value">{e(x["text"])}</div></div>' for x in doc['overview'])+'</div>'
    cards+=f'<p class="lead">{e(doc.get("overview_note",""))}</p>'
    if doc.get('scope_note'):cards+=f'<div class="callout amber"><strong class="callout-title">范围与前提</strong><p>{e(doc["scope_note"])}</p></div>'
    if doc.get('evidence_note'):cards+=f'<p class="evidence-line">{e(doc["evidence_note"])}</p>'
    section('journey-overview','核心判断','业务问题、客户任务与旅程完成标识',cards)
    for j in doc['journeys']:
        fragment=r.render(j)
        fragment=re.sub(r'^<h4>.*?</h4>','',fragment,count=1)
        section('section-'+j['id'],j['title'],j.get('nature',''),fragment,j.get('nav_title',j['title']))
    if doc.get('opportunities'):
        rows=[]
        for o in doc['opportunities']:
            kind={'高':'high','中':'medium','低':'low'}.get(o['priority'],'pending')
            rows.append(f'<tr><td>{e(o["title"])}</td><td>{e(o["problem"])}</td><td>{e(o["actions"])}</td><td>{r.badge(o["priority"],kind)}</td><td>{e(o["basis"])}</td></tr>')
        table='<div class="table-wrap"><table><thead><tr><th>机会</th><th>解决的问题</th><th>对应动作</th><th>优先级</th><th>判定依据 / 待验证</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'
        if doc.get('competition_note'):table+=f'<div class="callout green"><strong class="callout-title">对竞争力的含义</strong><p>{e(doc["competition_note"])}</p></div>'
        section('journey-opportunities','改进机会汇总','按对断点的直接作用排序。优先级是讨论起点，不是排期承诺。',table)
    verify='<ol>'+''.join(f'<li>{e(x)}</li>' for x in doc['verification'])+'</ol>'
    if doc.get('sources'):verify+='<p class="evidence-line">来源：'+e('；'.join(doc['sources']))+'</p>'
    section('journey-verification','待确认与验证','以访谈、任务走查和联调验证旅程假设',verify)
    s=re.sub(r'<title>.*?</title>','<title>'+e(doc['title'])+'｜用户旅程</title>',template,count=1)
    s=re.sub(r'(<nav class="toc" id="toc">).*?(</nav>)',lambda m:m[1]+''.join(nav)+m[2],s,count=1,flags=re.S)
    hero=f'''<section class="hero" aria-labelledby="page-title"><div class="hero-content"><div class="hero-kicker">USER JOURNEY · {e(doc['date'])}</div><h1 id="page-title">{e(doc['title'])}</h1><p class="hero-subtitle">{e(doc['subtitle'])}</p><p class="hero-intro">{e(doc['intro'])}</p><div class="meta-list">'''+''.join(f'<span class="meta-pill"><strong>{e(m["label"])}</strong>{e(m["text"])}</span>' for m in doc.get('meta',[]))+'</div></div></section>'
    s=re.sub(r'<section class="hero".*?</section>',lambda _:hero,s,count=1,flags=re.S)
    start=s.index('<section class="chapter"');end=s.index('<footer class="footer">',start)
    s=s[:start]+'\n'.join(sections)+'\n'+s[end:]
    s=re.sub(r'<footer class="footer">.*?</footer>',f'<footer class="footer"><span>用户旅程分析 · 角色协作 / 体验断点 / 改进机会</span><span>{e(doc["date"])}</span></footer>',s,count=1,flags=re.S)
    return s
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('data');p.add_argument('output');p.add_argument('--template',default=str(Path(__file__).resolve().parent.parent/'assets/user-journey-template.html'));args=p.parse_args()
    doc=json.loads(Path(args.data).read_text());html=build(doc,Path(args.template).read_text());Path(args.output).write_text(html)
